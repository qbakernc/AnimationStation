﻿namespace _16_x_8_LED_Control
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnSave = new System.Windows.Forms.Button();
            this.btnStart = new System.Windows.Forms.Button();
            this.ComPort = new System.Windows.Forms.ComboBox();
            this.BaudRate = new System.Windows.Forms.ComboBox();
            this.DataBits = new System.Windows.Forms.ComboBox();
            this.HandShake = new System.Windows.Forms.ComboBox();
            this.btnConnect = new System.Windows.Forms.Button();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.TxtFeedback = new System.Windows.Forms.TextBox();
            this.StopBits = new System.Windows.Forms.ComboBox();
            this.Parity = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.LED1 = new System.Windows.Forms.PictureBox();
            this.pnlSerialConnection = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.LED2 = new System.Windows.Forms.PictureBox();
            this.LED3 = new System.Windows.Forms.PictureBox();
            this.LED4 = new System.Windows.Forms.PictureBox();
            this.LED5 = new System.Windows.Forms.PictureBox();
            this.LED6 = new System.Windows.Forms.PictureBox();
            this.LED7 = new System.Windows.Forms.PictureBox();
            this.LED8 = new System.Windows.Forms.PictureBox();
            this.LED9 = new System.Windows.Forms.PictureBox();
            this.LED17 = new System.Windows.Forms.PictureBox();
            this.LED25 = new System.Windows.Forms.PictureBox();
            this.LED33 = new System.Windows.Forms.PictureBox();
            this.LED41 = new System.Windows.Forms.PictureBox();
            this.LED49 = new System.Windows.Forms.PictureBox();
            this.LED57 = new System.Windows.Forms.PictureBox();
            this.LED65 = new System.Windows.Forms.PictureBox();
            this.LED73 = new System.Windows.Forms.PictureBox();
            this.LED81 = new System.Windows.Forms.PictureBox();
            this.LED89 = new System.Windows.Forms.PictureBox();
            this.LED97 = new System.Windows.Forms.PictureBox();
            this.LED128 = new System.Windows.Forms.PictureBox();
            this.LED105 = new System.Windows.Forms.PictureBox();
            this.LED127 = new System.Windows.Forms.PictureBox();
            this.LED113 = new System.Windows.Forms.PictureBox();
            this.LED126 = new System.Windows.Forms.PictureBox();
            this.LED121 = new System.Windows.Forms.PictureBox();
            this.LED125 = new System.Windows.Forms.PictureBox();
            this.LED10 = new System.Windows.Forms.PictureBox();
            this.LED124 = new System.Windows.Forms.PictureBox();
            this.LED11 = new System.Windows.Forms.PictureBox();
            this.LED123 = new System.Windows.Forms.PictureBox();
            this.LED12 = new System.Windows.Forms.PictureBox();
            this.LED122 = new System.Windows.Forms.PictureBox();
            this.LED13 = new System.Windows.Forms.PictureBox();
            this.LED120 = new System.Windows.Forms.PictureBox();
            this.LED14 = new System.Windows.Forms.PictureBox();
            this.LED119 = new System.Windows.Forms.PictureBox();
            this.LED15 = new System.Windows.Forms.PictureBox();
            this.LED118 = new System.Windows.Forms.PictureBox();
            this.LED16 = new System.Windows.Forms.PictureBox();
            this.LED117 = new System.Windows.Forms.PictureBox();
            this.LED18 = new System.Windows.Forms.PictureBox();
            this.LED116 = new System.Windows.Forms.PictureBox();
            this.LED19 = new System.Windows.Forms.PictureBox();
            this.LED115 = new System.Windows.Forms.PictureBox();
            this.LED20 = new System.Windows.Forms.PictureBox();
            this.LED114 = new System.Windows.Forms.PictureBox();
            this.LED21 = new System.Windows.Forms.PictureBox();
            this.LED112 = new System.Windows.Forms.PictureBox();
            this.LED22 = new System.Windows.Forms.PictureBox();
            this.LED111 = new System.Windows.Forms.PictureBox();
            this.LED23 = new System.Windows.Forms.PictureBox();
            this.LED110 = new System.Windows.Forms.PictureBox();
            this.LED24 = new System.Windows.Forms.PictureBox();
            this.LED109 = new System.Windows.Forms.PictureBox();
            this.LED26 = new System.Windows.Forms.PictureBox();
            this.LED108 = new System.Windows.Forms.PictureBox();
            this.LED27 = new System.Windows.Forms.PictureBox();
            this.LED107 = new System.Windows.Forms.PictureBox();
            this.LED28 = new System.Windows.Forms.PictureBox();
            this.LED106 = new System.Windows.Forms.PictureBox();
            this.LED29 = new System.Windows.Forms.PictureBox();
            this.LED104 = new System.Windows.Forms.PictureBox();
            this.LED30 = new System.Windows.Forms.PictureBox();
            this.LED103 = new System.Windows.Forms.PictureBox();
            this.LED31 = new System.Windows.Forms.PictureBox();
            this.LED102 = new System.Windows.Forms.PictureBox();
            this.LED32 = new System.Windows.Forms.PictureBox();
            this.LED101 = new System.Windows.Forms.PictureBox();
            this.LED34 = new System.Windows.Forms.PictureBox();
            this.LED100 = new System.Windows.Forms.PictureBox();
            this.LED35 = new System.Windows.Forms.PictureBox();
            this.LED99 = new System.Windows.Forms.PictureBox();
            this.LED36 = new System.Windows.Forms.PictureBox();
            this.LED98 = new System.Windows.Forms.PictureBox();
            this.LED37 = new System.Windows.Forms.PictureBox();
            this.LED96 = new System.Windows.Forms.PictureBox();
            this.LED38 = new System.Windows.Forms.PictureBox();
            this.LED95 = new System.Windows.Forms.PictureBox();
            this.LED39 = new System.Windows.Forms.PictureBox();
            this.LED94 = new System.Windows.Forms.PictureBox();
            this.LED40 = new System.Windows.Forms.PictureBox();
            this.LED93 = new System.Windows.Forms.PictureBox();
            this.LED42 = new System.Windows.Forms.PictureBox();
            this.LED92 = new System.Windows.Forms.PictureBox();
            this.LED43 = new System.Windows.Forms.PictureBox();
            this.LED91 = new System.Windows.Forms.PictureBox();
            this.LED44 = new System.Windows.Forms.PictureBox();
            this.LED90 = new System.Windows.Forms.PictureBox();
            this.LED45 = new System.Windows.Forms.PictureBox();
            this.LED88 = new System.Windows.Forms.PictureBox();
            this.LED46 = new System.Windows.Forms.PictureBox();
            this.LED87 = new System.Windows.Forms.PictureBox();
            this.LED47 = new System.Windows.Forms.PictureBox();
            this.LED86 = new System.Windows.Forms.PictureBox();
            this.LED48 = new System.Windows.Forms.PictureBox();
            this.LED85 = new System.Windows.Forms.PictureBox();
            this.LED50 = new System.Windows.Forms.PictureBox();
            this.LED84 = new System.Windows.Forms.PictureBox();
            this.LED51 = new System.Windows.Forms.PictureBox();
            this.LED83 = new System.Windows.Forms.PictureBox();
            this.LED52 = new System.Windows.Forms.PictureBox();
            this.LED82 = new System.Windows.Forms.PictureBox();
            this.LED53 = new System.Windows.Forms.PictureBox();
            this.LED80 = new System.Windows.Forms.PictureBox();
            this.LED54 = new System.Windows.Forms.PictureBox();
            this.LED79 = new System.Windows.Forms.PictureBox();
            this.LED55 = new System.Windows.Forms.PictureBox();
            this.LED78 = new System.Windows.Forms.PictureBox();
            this.LED56 = new System.Windows.Forms.PictureBox();
            this.LED77 = new System.Windows.Forms.PictureBox();
            this.LED58 = new System.Windows.Forms.PictureBox();
            this.LED76 = new System.Windows.Forms.PictureBox();
            this.LED59 = new System.Windows.Forms.PictureBox();
            this.LED75 = new System.Windows.Forms.PictureBox();
            this.LED60 = new System.Windows.Forms.PictureBox();
            this.LED74 = new System.Windows.Forms.PictureBox();
            this.LED61 = new System.Windows.Forms.PictureBox();
            this.LED72 = new System.Windows.Forms.PictureBox();
            this.LED62 = new System.Windows.Forms.PictureBox();
            this.LED71 = new System.Windows.Forms.PictureBox();
            this.LED63 = new System.Windows.Forms.PictureBox();
            this.LED70 = new System.Windows.Forms.PictureBox();
            this.LED64 = new System.Windows.Forms.PictureBox();
            this.LED69 = new System.Windows.Forms.PictureBox();
            this.LED66 = new System.Windows.Forms.PictureBox();
            this.LED68 = new System.Windows.Forms.PictureBox();
            this.LED67 = new System.Windows.Forms.PictureBox();
            this.matrixBackground = new System.Windows.Forms.PictureBox();
            this.btn100ms = new System.Windows.Forms.Button();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.btn1000ms = new System.Windows.Forms.Button();
            this.btn500ms = new System.Windows.Forms.Button();
            this.btn250ms = new System.Windows.Forms.Button();
            this.txtCount = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LED1)).BeginInit();
            this.pnlSerialConnection.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LED2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED41)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED49)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED57)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED65)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED73)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED81)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED89)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED97)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED128)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED105)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED127)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED113)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED126)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED121)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED125)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED124)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED123)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED122)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED120)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED119)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED118)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED117)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED116)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED115)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED114)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED112)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED111)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED110)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED109)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED108)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED107)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED106)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED104)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED30)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED103)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED102)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED101)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED100)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED99)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED98)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED96)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED38)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED95)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED39)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED94)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED40)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED93)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED42)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED92)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED43)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED91)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED44)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED90)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED45)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED88)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED46)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED87)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED47)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED86)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED48)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED85)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED50)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED84)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED51)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED83)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED52)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED82)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED53)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED80)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED54)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED79)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED55)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED78)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED56)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED77)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED58)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED76)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED59)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED75)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED60)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED74)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED61)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED72)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED62)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED71)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED63)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED70)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED64)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED69)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED66)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED68)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED67)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.matrixBackground)).BeginInit();
            this.SuspendLayout();
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(33)))), ((int)(((byte)(45)))));
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(63)))), ((int)(((byte)(75)))));
            this.btnSave.Location = new System.Drawing.Point(307, 304);
            this.btnSave.Name = "btnSave";
            this.btnSave.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnSave.Size = new System.Drawing.Size(80, 30);
            this.btnSave.TabIndex = 11;
            this.btnSave.Text = "Latch";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnStart
            // 
            this.btnStart.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(33)))), ((int)(((byte)(45)))));
            this.btnStart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStart.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStart.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(63)))), ((int)(((byte)(75)))));
            this.btnStart.Location = new System.Drawing.Point(383, 304);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(80, 30);
            this.btnStart.TabIndex = 12;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = false;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // ComPort
            // 
            this.ComPort.BackColor = System.Drawing.Color.White;
            this.ComPort.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComPort.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ComPort.ForeColor = System.Drawing.SystemColors.WindowText;
            this.ComPort.FormattingEnabled = true;
            this.ComPort.Location = new System.Drawing.Point(145, 65);
            this.ComPort.Name = "ComPort";
            this.ComPort.Size = new System.Drawing.Size(55, 21);
            this.ComPort.TabIndex = 15;
            this.ComPort.SelectedIndexChanged += new System.EventHandler(this.ComPort_SelectedIndexChanged);
            // 
            // BaudRate
            // 
            this.BaudRate.BackColor = System.Drawing.Color.White;
            this.BaudRate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.BaudRate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BaudRate.FormattingEnabled = true;
            this.BaudRate.Location = new System.Drawing.Point(145, 92);
            this.BaudRate.Name = "BaudRate";
            this.BaudRate.Size = new System.Drawing.Size(55, 21);
            this.BaudRate.TabIndex = 16;
            // 
            // DataBits
            // 
            this.DataBits.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.DataBits.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DataBits.FormattingEnabled = true;
            this.DataBits.Location = new System.Drawing.Point(145, 119);
            this.DataBits.Name = "DataBits";
            this.DataBits.Size = new System.Drawing.Size(55, 21);
            this.DataBits.TabIndex = 17;
            // 
            // HandShake
            // 
            this.HandShake.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.HandShake.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.HandShake.FormattingEnabled = true;
            this.HandShake.Location = new System.Drawing.Point(145, 146);
            this.HandShake.Name = "HandShake";
            this.HandShake.Size = new System.Drawing.Size(55, 21);
            this.HandShake.TabIndex = 18;
            // 
            // btnConnect
            // 
            this.btnConnect.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(33)))), ((int)(((byte)(45)))));
            this.btnConnect.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnConnect.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnConnect.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConnect.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(63)))), ((int)(((byte)(75)))));
            this.btnConnect.Location = new System.Drawing.Point(462, 304);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(108, 30);
            this.btnConnect.TabIndex = 19;
            this.btnConnect.Text = "Connect";
            this.btnConnect.UseVisualStyleBackColor = false;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // serialPort1
            // 
            this.serialPort1.PortName = "COM5";
            // 
            // TxtFeedback
            // 
            this.TxtFeedback.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.TxtFeedback.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.TxtFeedback.Location = new System.Drawing.Point(4, 312);
            this.TxtFeedback.Name = "TxtFeedback";
            this.TxtFeedback.Size = new System.Drawing.Size(50, 20);
            this.TxtFeedback.TabIndex = 22;
            this.TxtFeedback.Visible = false;
            // 
            // StopBits
            // 
            this.StopBits.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.StopBits.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.StopBits.FormattingEnabled = true;
            this.StopBits.Location = new System.Drawing.Point(145, 173);
            this.StopBits.Name = "StopBits";
            this.StopBits.Size = new System.Drawing.Size(55, 21);
            this.StopBits.TabIndex = 152;
            // 
            // Parity
            // 
            this.Parity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Parity.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Parity.FormattingEnabled = true;
            this.Parity.Location = new System.Drawing.Point(145, 200);
            this.Parity.Name = "Parity";
            this.Parity.Size = new System.Drawing.Size(55, 21);
            this.Parity.TabIndex = 153;
            this.Parity.SelectedIndexChanged += new System.EventHandler(this.Parity_SelectedIndexChanged);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.LED1);
            this.panel1.Controls.Add(this.pnlSerialConnection);
            this.panel1.Controls.Add(this.LED2);
            this.panel1.Controls.Add(this.LED3);
            this.panel1.Controls.Add(this.LED4);
            this.panel1.Controls.Add(this.LED5);
            this.panel1.Controls.Add(this.LED6);
            this.panel1.Controls.Add(this.LED7);
            this.panel1.Controls.Add(this.LED8);
            this.panel1.Controls.Add(this.LED9);
            this.panel1.Controls.Add(this.LED17);
            this.panel1.Controls.Add(this.LED25);
            this.panel1.Controls.Add(this.LED33);
            this.panel1.Controls.Add(this.LED41);
            this.panel1.Controls.Add(this.LED49);
            this.panel1.Controls.Add(this.LED57);
            this.panel1.Controls.Add(this.LED65);
            this.panel1.Controls.Add(this.LED73);
            this.panel1.Controls.Add(this.LED81);
            this.panel1.Controls.Add(this.LED89);
            this.panel1.Controls.Add(this.LED97);
            this.panel1.Controls.Add(this.LED128);
            this.panel1.Controls.Add(this.LED105);
            this.panel1.Controls.Add(this.LED127);
            this.panel1.Controls.Add(this.LED113);
            this.panel1.Controls.Add(this.LED126);
            this.panel1.Controls.Add(this.LED121);
            this.panel1.Controls.Add(this.LED125);
            this.panel1.Controls.Add(this.LED10);
            this.panel1.Controls.Add(this.LED124);
            this.panel1.Controls.Add(this.LED11);
            this.panel1.Controls.Add(this.LED123);
            this.panel1.Controls.Add(this.LED12);
            this.panel1.Controls.Add(this.LED122);
            this.panel1.Controls.Add(this.LED13);
            this.panel1.Controls.Add(this.LED120);
            this.panel1.Controls.Add(this.LED14);
            this.panel1.Controls.Add(this.LED119);
            this.panel1.Controls.Add(this.LED15);
            this.panel1.Controls.Add(this.LED118);
            this.panel1.Controls.Add(this.LED16);
            this.panel1.Controls.Add(this.LED117);
            this.panel1.Controls.Add(this.LED18);
            this.panel1.Controls.Add(this.LED116);
            this.panel1.Controls.Add(this.LED19);
            this.panel1.Controls.Add(this.LED115);
            this.panel1.Controls.Add(this.LED20);
            this.panel1.Controls.Add(this.LED114);
            this.panel1.Controls.Add(this.LED21);
            this.panel1.Controls.Add(this.LED112);
            this.panel1.Controls.Add(this.LED22);
            this.panel1.Controls.Add(this.LED111);
            this.panel1.Controls.Add(this.LED23);
            this.panel1.Controls.Add(this.LED110);
            this.panel1.Controls.Add(this.LED24);
            this.panel1.Controls.Add(this.LED109);
            this.panel1.Controls.Add(this.LED26);
            this.panel1.Controls.Add(this.LED108);
            this.panel1.Controls.Add(this.LED27);
            this.panel1.Controls.Add(this.LED107);
            this.panel1.Controls.Add(this.LED28);
            this.panel1.Controls.Add(this.LED106);
            this.panel1.Controls.Add(this.LED29);
            this.panel1.Controls.Add(this.LED104);
            this.panel1.Controls.Add(this.LED30);
            this.panel1.Controls.Add(this.LED103);
            this.panel1.Controls.Add(this.LED31);
            this.panel1.Controls.Add(this.LED102);
            this.panel1.Controls.Add(this.LED32);
            this.panel1.Controls.Add(this.LED101);
            this.panel1.Controls.Add(this.LED34);
            this.panel1.Controls.Add(this.LED100);
            this.panel1.Controls.Add(this.LED35);
            this.panel1.Controls.Add(this.LED99);
            this.panel1.Controls.Add(this.LED36);
            this.panel1.Controls.Add(this.LED98);
            this.panel1.Controls.Add(this.LED37);
            this.panel1.Controls.Add(this.LED96);
            this.panel1.Controls.Add(this.LED38);
            this.panel1.Controls.Add(this.LED95);
            this.panel1.Controls.Add(this.LED39);
            this.panel1.Controls.Add(this.LED94);
            this.panel1.Controls.Add(this.LED40);
            this.panel1.Controls.Add(this.LED93);
            this.panel1.Controls.Add(this.LED42);
            this.panel1.Controls.Add(this.LED92);
            this.panel1.Controls.Add(this.LED43);
            this.panel1.Controls.Add(this.LED91);
            this.panel1.Controls.Add(this.LED44);
            this.panel1.Controls.Add(this.LED90);
            this.panel1.Controls.Add(this.LED45);
            this.panel1.Controls.Add(this.LED88);
            this.panel1.Controls.Add(this.LED46);
            this.panel1.Controls.Add(this.LED87);
            this.panel1.Controls.Add(this.LED47);
            this.panel1.Controls.Add(this.LED86);
            this.panel1.Controls.Add(this.LED48);
            this.panel1.Controls.Add(this.LED85);
            this.panel1.Controls.Add(this.LED50);
            this.panel1.Controls.Add(this.LED84);
            this.panel1.Controls.Add(this.LED51);
            this.panel1.Controls.Add(this.LED83);
            this.panel1.Controls.Add(this.LED52);
            this.panel1.Controls.Add(this.LED82);
            this.panel1.Controls.Add(this.LED53);
            this.panel1.Controls.Add(this.LED80);
            this.panel1.Controls.Add(this.LED54);
            this.panel1.Controls.Add(this.LED79);
            this.panel1.Controls.Add(this.LED55);
            this.panel1.Controls.Add(this.LED78);
            this.panel1.Controls.Add(this.LED56);
            this.panel1.Controls.Add(this.LED77);
            this.panel1.Controls.Add(this.LED58);
            this.panel1.Controls.Add(this.LED76);
            this.panel1.Controls.Add(this.LED59);
            this.panel1.Controls.Add(this.LED75);
            this.panel1.Controls.Add(this.LED60);
            this.panel1.Controls.Add(this.LED74);
            this.panel1.Controls.Add(this.LED61);
            this.panel1.Controls.Add(this.LED72);
            this.panel1.Controls.Add(this.LED62);
            this.panel1.Controls.Add(this.LED71);
            this.panel1.Controls.Add(this.LED63);
            this.panel1.Controls.Add(this.LED70);
            this.panel1.Controls.Add(this.LED64);
            this.panel1.Controls.Add(this.LED69);
            this.panel1.Controls.Add(this.LED66);
            this.panel1.Controls.Add(this.LED68);
            this.panel1.Controls.Add(this.LED67);
            this.panel1.Controls.Add(this.matrixBackground);
            this.panel1.Location = new System.Drawing.Point(1, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(604, 300);
            this.panel1.TabIndex = 170;
            // 
            // LED1
            // 
            this.LED1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.LED1.Image = global::_16_x_8_LED_Control.Properties.Resources.Red_Circle_Transparent;
            this.LED1.InitialImage = null;
            this.LED1.Location = new System.Drawing.Point(3, 268);
            this.LED1.Name = "LED1";
            this.LED1.Size = new System.Drawing.Size(30, 30);
            this.LED1.TabIndex = 24;
            this.LED1.TabStop = false;
            this.LED1.Tag = "A";
            this.LED1.Click += new System.EventHandler(this.LED1_Click);
            // 
            // pnlSerialConnection
            // 
            this.pnlSerialConnection.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(33)))), ((int)(((byte)(45)))));
            this.pnlSerialConnection.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlSerialConnection.Controls.Add(this.label7);
            this.pnlSerialConnection.Controls.Add(this.label6);
            this.pnlSerialConnection.Controls.Add(this.label5);
            this.pnlSerialConnection.Controls.Add(this.label4);
            this.pnlSerialConnection.Controls.Add(this.label3);
            this.pnlSerialConnection.Controls.Add(this.label2);
            this.pnlSerialConnection.Controls.Add(this.label1);
            this.pnlSerialConnection.Controls.Add(this.ComPort);
            this.pnlSerialConnection.Controls.Add(this.BaudRate);
            this.pnlSerialConnection.Controls.Add(this.DataBits);
            this.pnlSerialConnection.Controls.Add(this.HandShake);
            this.pnlSerialConnection.Controls.Add(this.StopBits);
            this.pnlSerialConnection.Controls.Add(this.Parity);
            this.pnlSerialConnection.Location = new System.Drawing.Point(199, 40);
            this.pnlSerialConnection.Name = "pnlSerialConnection";
            this.pnlSerialConnection.Size = new System.Drawing.Size(206, 230);
            this.pnlSerialConnection.TabIndex = 174;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(0, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(206, 52);
            this.label7.TabIndex = 175;
            this.label7.Text = "Communication Setup";
            this.label7.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(3, 198);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 21);
            this.label6.TabIndex = 180;
            this.label6.Text = "Parity:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(3, 174);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 21);
            this.label5.TabIndex = 179;
            this.label5.Text = "Stop Bits:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(3, 147);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 21);
            this.label4.TabIndex = 178;
            this.label4.Text = "Handshake:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(3, 119);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 21);
            this.label3.TabIndex = 177;
            this.label3.Text = "Data Bits:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(3, 93);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 21);
            this.label2.TabIndex = 176;
            this.label2.Text = "Baud Rate:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(3, 65);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 21);
            this.label1.TabIndex = 175;
            this.label1.Text = "Com Port:";
            // 
            // LED2
            // 
            this.LED2.Image = global::_16_x_8_LED_Control.Properties.Resources.Red_Circle_Transparent;
            this.LED2.Location = new System.Drawing.Point(3, 230);
            this.LED2.Name = "LED2";
            this.LED2.Size = new System.Drawing.Size(30, 30);
            this.LED2.TabIndex = 25;
            this.LED2.TabStop = false;
            this.LED2.Tag = "A";
            this.LED2.Click += new System.EventHandler(this.LED2_Click);
            // 
            // LED3
            // 
            this.LED3.Image = global::_16_x_8_LED_Control.Properties.Resources.Red_Circle_Transparent;
            this.LED3.Location = new System.Drawing.Point(3, 192);
            this.LED3.Name = "LED3";
            this.LED3.Size = new System.Drawing.Size(30, 30);
            this.LED3.TabIndex = 26;
            this.LED3.TabStop = false;
            this.LED3.Tag = "A";
            this.LED3.Click += new System.EventHandler(this.LED3_Click);
            // 
            // LED4
            // 
            this.LED4.Image = ((System.Drawing.Image)(resources.GetObject("LED4.Image")));
            this.LED4.Location = new System.Drawing.Point(3, 154);
            this.LED4.Name = "LED4";
            this.LED4.Size = new System.Drawing.Size(30, 30);
            this.LED4.TabIndex = 27;
            this.LED4.TabStop = false;
            this.LED4.Tag = "A";
            this.LED4.Click += new System.EventHandler(this.LED4_Click);
            // 
            // LED5
            // 
            this.LED5.Image = ((System.Drawing.Image)(resources.GetObject("LED5.Image")));
            this.LED5.Location = new System.Drawing.Point(3, 116);
            this.LED5.Name = "LED5";
            this.LED5.Size = new System.Drawing.Size(30, 30);
            this.LED5.TabIndex = 28;
            this.LED5.TabStop = false;
            this.LED5.Tag = "A";
            this.LED5.Click += new System.EventHandler(this.LED5_Click);
            // 
            // LED6
            // 
            this.LED6.Image = ((System.Drawing.Image)(resources.GetObject("LED6.Image")));
            this.LED6.Location = new System.Drawing.Point(3, 78);
            this.LED6.Name = "LED6";
            this.LED6.Size = new System.Drawing.Size(30, 30);
            this.LED6.TabIndex = 29;
            this.LED6.TabStop = false;
            this.LED6.Tag = "A";
            this.LED6.Click += new System.EventHandler(this.LED6_Click);
            // 
            // LED7
            // 
            this.LED7.Image = ((System.Drawing.Image)(resources.GetObject("LED7.Image")));
            this.LED7.Location = new System.Drawing.Point(3, 40);
            this.LED7.Name = "LED7";
            this.LED7.Size = new System.Drawing.Size(30, 30);
            this.LED7.TabIndex = 30;
            this.LED7.TabStop = false;
            this.LED7.Tag = "A";
            this.LED7.Click += new System.EventHandler(this.LED7_Click);
            // 
            // LED8
            // 
            this.LED8.Image = ((System.Drawing.Image)(resources.GetObject("LED8.Image")));
            this.LED8.Location = new System.Drawing.Point(3, 2);
            this.LED8.Name = "LED8";
            this.LED8.Size = new System.Drawing.Size(30, 30);
            this.LED8.TabIndex = 31;
            this.LED8.TabStop = false;
            this.LED8.Tag = "A";
            this.LED8.Click += new System.EventHandler(this.LED8_Click);
            // 
            // LED9
            // 
            this.LED9.Image = ((System.Drawing.Image)(resources.GetObject("LED9.Image")));
            this.LED9.InitialImage = null;
            this.LED9.Location = new System.Drawing.Point(40, 268);
            this.LED9.Name = "LED9";
            this.LED9.Size = new System.Drawing.Size(30, 30);
            this.LED9.TabIndex = 32;
            this.LED9.TabStop = false;
            this.LED9.Tag = "A";
            this.LED9.Click += new System.EventHandler(this.LED9_Click);
            // 
            // LED17
            // 
            this.LED17.Image = ((System.Drawing.Image)(resources.GetObject("LED17.Image")));
            this.LED17.InitialImage = null;
            this.LED17.Location = new System.Drawing.Point(78, 268);
            this.LED17.Name = "LED17";
            this.LED17.Size = new System.Drawing.Size(30, 30);
            this.LED17.TabIndex = 33;
            this.LED17.TabStop = false;
            this.LED17.Tag = "A";
            this.LED17.Click += new System.EventHandler(this.LED17_Click);
            // 
            // LED25
            // 
            this.LED25.Image = ((System.Drawing.Image)(resources.GetObject("LED25.Image")));
            this.LED25.InitialImage = null;
            this.LED25.Location = new System.Drawing.Point(116, 268);
            this.LED25.Name = "LED25";
            this.LED25.Size = new System.Drawing.Size(30, 30);
            this.LED25.TabIndex = 34;
            this.LED25.TabStop = false;
            this.LED25.Tag = "A";
            this.LED25.Click += new System.EventHandler(this.LED25_Click);
            // 
            // LED33
            // 
            this.LED33.Image = ((System.Drawing.Image)(resources.GetObject("LED33.Image")));
            this.LED33.InitialImage = null;
            this.LED33.Location = new System.Drawing.Point(154, 268);
            this.LED33.Name = "LED33";
            this.LED33.Size = new System.Drawing.Size(30, 30);
            this.LED33.TabIndex = 35;
            this.LED33.TabStop = false;
            this.LED33.Tag = "A";
            this.LED33.Click += new System.EventHandler(this.LED33_Click);
            // 
            // LED41
            // 
            this.LED41.Image = ((System.Drawing.Image)(resources.GetObject("LED41.Image")));
            this.LED41.InitialImage = null;
            this.LED41.Location = new System.Drawing.Point(192, 268);
            this.LED41.Name = "LED41";
            this.LED41.Size = new System.Drawing.Size(30, 30);
            this.LED41.TabIndex = 36;
            this.LED41.TabStop = false;
            this.LED41.Tag = "A";
            this.LED41.Click += new System.EventHandler(this.LED41_Click);
            // 
            // LED49
            // 
            this.LED49.Image = ((System.Drawing.Image)(resources.GetObject("LED49.Image")));
            this.LED49.InitialImage = null;
            this.LED49.Location = new System.Drawing.Point(230, 268);
            this.LED49.Name = "LED49";
            this.LED49.Size = new System.Drawing.Size(30, 30);
            this.LED49.TabIndex = 37;
            this.LED49.TabStop = false;
            this.LED49.Tag = "A";
            this.LED49.Click += new System.EventHandler(this.LED49_Click);
            // 
            // LED57
            // 
            this.LED57.Image = ((System.Drawing.Image)(resources.GetObject("LED57.Image")));
            this.LED57.InitialImage = null;
            this.LED57.Location = new System.Drawing.Point(268, 268);
            this.LED57.Name = "LED57";
            this.LED57.Size = new System.Drawing.Size(30, 30);
            this.LED57.TabIndex = 38;
            this.LED57.TabStop = false;
            this.LED57.Tag = "A";
            this.LED57.Click += new System.EventHandler(this.LED57_Click);
            // 
            // LED65
            // 
            this.LED65.Image = ((System.Drawing.Image)(resources.GetObject("LED65.Image")));
            this.LED65.InitialImage = null;
            this.LED65.Location = new System.Drawing.Point(306, 268);
            this.LED65.Name = "LED65";
            this.LED65.Size = new System.Drawing.Size(30, 30);
            this.LED65.TabIndex = 39;
            this.LED65.TabStop = false;
            this.LED65.Tag = "A";
            this.LED65.Click += new System.EventHandler(this.LED65_Click);
            // 
            // LED73
            // 
            this.LED73.Image = ((System.Drawing.Image)(resources.GetObject("LED73.Image")));
            this.LED73.InitialImage = null;
            this.LED73.Location = new System.Drawing.Point(344, 268);
            this.LED73.Name = "LED73";
            this.LED73.Size = new System.Drawing.Size(30, 30);
            this.LED73.TabIndex = 40;
            this.LED73.TabStop = false;
            this.LED73.Tag = "A";
            this.LED73.Click += new System.EventHandler(this.LED73_Click);
            // 
            // LED81
            // 
            this.LED81.Image = ((System.Drawing.Image)(resources.GetObject("LED81.Image")));
            this.LED81.InitialImage = null;
            this.LED81.Location = new System.Drawing.Point(382, 268);
            this.LED81.Name = "LED81";
            this.LED81.Size = new System.Drawing.Size(30, 30);
            this.LED81.TabIndex = 41;
            this.LED81.TabStop = false;
            this.LED81.Tag = "A";
            this.LED81.Click += new System.EventHandler(this.LED81_Click);
            // 
            // LED89
            // 
            this.LED89.Image = ((System.Drawing.Image)(resources.GetObject("LED89.Image")));
            this.LED89.InitialImage = null;
            this.LED89.Location = new System.Drawing.Point(420, 268);
            this.LED89.Name = "LED89";
            this.LED89.Size = new System.Drawing.Size(30, 30);
            this.LED89.TabIndex = 42;
            this.LED89.TabStop = false;
            this.LED89.Tag = "A";
            this.LED89.Click += new System.EventHandler(this.LED89_Click);
            // 
            // LED97
            // 
            this.LED97.Image = ((System.Drawing.Image)(resources.GetObject("LED97.Image")));
            this.LED97.InitialImage = null;
            this.LED97.Location = new System.Drawing.Point(458, 268);
            this.LED97.Name = "LED97";
            this.LED97.Size = new System.Drawing.Size(30, 30);
            this.LED97.TabIndex = 43;
            this.LED97.TabStop = false;
            this.LED97.Tag = "A";
            this.LED97.Click += new System.EventHandler(this.LED97_Click);
            // 
            // LED128
            // 
            this.LED128.Image = ((System.Drawing.Image)(resources.GetObject("LED128.Image")));
            this.LED128.Location = new System.Drawing.Point(572, 2);
            this.LED128.Name = "LED128";
            this.LED128.Size = new System.Drawing.Size(30, 30);
            this.LED128.TabIndex = 151;
            this.LED128.TabStop = false;
            this.LED128.Tag = "A";
            this.LED128.Click += new System.EventHandler(this.LED128_Click);
            // 
            // LED105
            // 
            this.LED105.Image = ((System.Drawing.Image)(resources.GetObject("LED105.Image")));
            this.LED105.InitialImage = null;
            this.LED105.Location = new System.Drawing.Point(496, 268);
            this.LED105.Name = "LED105";
            this.LED105.Size = new System.Drawing.Size(30, 30);
            this.LED105.TabIndex = 44;
            this.LED105.TabStop = false;
            this.LED105.Tag = "A";
            this.LED105.Click += new System.EventHandler(this.LED105_Click);
            // 
            // LED127
            // 
            this.LED127.Image = ((System.Drawing.Image)(resources.GetObject("LED127.Image")));
            this.LED127.Location = new System.Drawing.Point(572, 40);
            this.LED127.Name = "LED127";
            this.LED127.Size = new System.Drawing.Size(30, 30);
            this.LED127.TabIndex = 150;
            this.LED127.TabStop = false;
            this.LED127.Tag = "A";
            this.LED127.Click += new System.EventHandler(this.LED127_Click);
            // 
            // LED113
            // 
            this.LED113.Image = ((System.Drawing.Image)(resources.GetObject("LED113.Image")));
            this.LED113.InitialImage = null;
            this.LED113.Location = new System.Drawing.Point(534, 268);
            this.LED113.Name = "LED113";
            this.LED113.Size = new System.Drawing.Size(30, 30);
            this.LED113.TabIndex = 45;
            this.LED113.TabStop = false;
            this.LED113.Tag = "A";
            this.LED113.Click += new System.EventHandler(this.LED113_Click);
            // 
            // LED126
            // 
            this.LED126.Image = ((System.Drawing.Image)(resources.GetObject("LED126.Image")));
            this.LED126.Location = new System.Drawing.Point(572, 78);
            this.LED126.Name = "LED126";
            this.LED126.Size = new System.Drawing.Size(30, 30);
            this.LED126.TabIndex = 149;
            this.LED126.TabStop = false;
            this.LED126.Tag = "A";
            this.LED126.Click += new System.EventHandler(this.LED126_Click);
            // 
            // LED121
            // 
            this.LED121.Image = ((System.Drawing.Image)(resources.GetObject("LED121.Image")));
            this.LED121.InitialImage = null;
            this.LED121.Location = new System.Drawing.Point(572, 268);
            this.LED121.Name = "LED121";
            this.LED121.Size = new System.Drawing.Size(30, 30);
            this.LED121.TabIndex = 46;
            this.LED121.TabStop = false;
            this.LED121.Tag = "A";
            this.LED121.Click += new System.EventHandler(this.LED121_Click);
            // 
            // LED125
            // 
            this.LED125.Image = ((System.Drawing.Image)(resources.GetObject("LED125.Image")));
            this.LED125.Location = new System.Drawing.Point(572, 116);
            this.LED125.Name = "LED125";
            this.LED125.Size = new System.Drawing.Size(30, 30);
            this.LED125.TabIndex = 148;
            this.LED125.TabStop = false;
            this.LED125.Tag = "A";
            this.LED125.Click += new System.EventHandler(this.LED125_Click);
            // 
            // LED10
            // 
            this.LED10.Image = ((System.Drawing.Image)(resources.GetObject("LED10.Image")));
            this.LED10.Location = new System.Drawing.Point(40, 230);
            this.LED10.Name = "LED10";
            this.LED10.Size = new System.Drawing.Size(30, 30);
            this.LED10.TabIndex = 47;
            this.LED10.TabStop = false;
            this.LED10.Tag = "A";
            this.LED10.Click += new System.EventHandler(this.LED10_Click);
            // 
            // LED124
            // 
            this.LED124.Image = ((System.Drawing.Image)(resources.GetObject("LED124.Image")));
            this.LED124.Location = new System.Drawing.Point(572, 154);
            this.LED124.Name = "LED124";
            this.LED124.Size = new System.Drawing.Size(30, 30);
            this.LED124.TabIndex = 147;
            this.LED124.TabStop = false;
            this.LED124.Tag = "A";
            this.LED124.Click += new System.EventHandler(this.LED124_Click);
            // 
            // LED11
            // 
            this.LED11.Image = ((System.Drawing.Image)(resources.GetObject("LED11.Image")));
            this.LED11.Location = new System.Drawing.Point(40, 192);
            this.LED11.Name = "LED11";
            this.LED11.Size = new System.Drawing.Size(30, 30);
            this.LED11.TabIndex = 48;
            this.LED11.TabStop = false;
            this.LED11.Tag = "A";
            this.LED11.Click += new System.EventHandler(this.LED11_Click);
            // 
            // LED123
            // 
            this.LED123.Image = ((System.Drawing.Image)(resources.GetObject("LED123.Image")));
            this.LED123.Location = new System.Drawing.Point(572, 192);
            this.LED123.Name = "LED123";
            this.LED123.Size = new System.Drawing.Size(30, 30);
            this.LED123.TabIndex = 146;
            this.LED123.TabStop = false;
            this.LED123.Tag = "A";
            this.LED123.Click += new System.EventHandler(this.LED123_Click);
            // 
            // LED12
            // 
            this.LED12.Image = ((System.Drawing.Image)(resources.GetObject("LED12.Image")));
            this.LED12.Location = new System.Drawing.Point(40, 154);
            this.LED12.Name = "LED12";
            this.LED12.Size = new System.Drawing.Size(30, 30);
            this.LED12.TabIndex = 49;
            this.LED12.TabStop = false;
            this.LED12.Tag = "A";
            this.LED12.Click += new System.EventHandler(this.LED12_Click);
            // 
            // LED122
            // 
            this.LED122.Image = ((System.Drawing.Image)(resources.GetObject("LED122.Image")));
            this.LED122.Location = new System.Drawing.Point(572, 230);
            this.LED122.Name = "LED122";
            this.LED122.Size = new System.Drawing.Size(30, 30);
            this.LED122.TabIndex = 145;
            this.LED122.TabStop = false;
            this.LED122.Tag = "A";
            this.LED122.Click += new System.EventHandler(this.LED122_Click);
            // 
            // LED13
            // 
            this.LED13.Image = ((System.Drawing.Image)(resources.GetObject("LED13.Image")));
            this.LED13.Location = new System.Drawing.Point(40, 116);
            this.LED13.Name = "LED13";
            this.LED13.Size = new System.Drawing.Size(30, 30);
            this.LED13.TabIndex = 50;
            this.LED13.TabStop = false;
            this.LED13.Tag = "A";
            this.LED13.Click += new System.EventHandler(this.LED13_Click);
            // 
            // LED120
            // 
            this.LED120.Image = ((System.Drawing.Image)(resources.GetObject("LED120.Image")));
            this.LED120.Location = new System.Drawing.Point(534, 2);
            this.LED120.Name = "LED120";
            this.LED120.Size = new System.Drawing.Size(30, 30);
            this.LED120.TabIndex = 144;
            this.LED120.TabStop = false;
            this.LED120.Tag = "A";
            this.LED120.Click += new System.EventHandler(this.LED120_Click);
            // 
            // LED14
            // 
            this.LED14.Image = ((System.Drawing.Image)(resources.GetObject("LED14.Image")));
            this.LED14.Location = new System.Drawing.Point(40, 78);
            this.LED14.Name = "LED14";
            this.LED14.Size = new System.Drawing.Size(30, 30);
            this.LED14.TabIndex = 51;
            this.LED14.TabStop = false;
            this.LED14.Tag = "A";
            this.LED14.Click += new System.EventHandler(this.LED14_Click);
            // 
            // LED119
            // 
            this.LED119.Image = ((System.Drawing.Image)(resources.GetObject("LED119.Image")));
            this.LED119.Location = new System.Drawing.Point(534, 40);
            this.LED119.Name = "LED119";
            this.LED119.Size = new System.Drawing.Size(30, 30);
            this.LED119.TabIndex = 143;
            this.LED119.TabStop = false;
            this.LED119.Tag = "A";
            this.LED119.Click += new System.EventHandler(this.LED119_Click);
            // 
            // LED15
            // 
            this.LED15.Image = ((System.Drawing.Image)(resources.GetObject("LED15.Image")));
            this.LED15.Location = new System.Drawing.Point(40, 40);
            this.LED15.Name = "LED15";
            this.LED15.Size = new System.Drawing.Size(30, 30);
            this.LED15.TabIndex = 52;
            this.LED15.TabStop = false;
            this.LED15.Tag = "A";
            this.LED15.Click += new System.EventHandler(this.LED15_Click);
            // 
            // LED118
            // 
            this.LED118.Image = ((System.Drawing.Image)(resources.GetObject("LED118.Image")));
            this.LED118.Location = new System.Drawing.Point(534, 78);
            this.LED118.Name = "LED118";
            this.LED118.Size = new System.Drawing.Size(30, 30);
            this.LED118.TabIndex = 142;
            this.LED118.TabStop = false;
            this.LED118.Tag = "A";
            this.LED118.Click += new System.EventHandler(this.LED118_Click);
            // 
            // LED16
            // 
            this.LED16.Image = ((System.Drawing.Image)(resources.GetObject("LED16.Image")));
            this.LED16.Location = new System.Drawing.Point(40, 2);
            this.LED16.Name = "LED16";
            this.LED16.Size = new System.Drawing.Size(30, 30);
            this.LED16.TabIndex = 53;
            this.LED16.TabStop = false;
            this.LED16.Tag = "A";
            this.LED16.Click += new System.EventHandler(this.LED16_Click);
            // 
            // LED117
            // 
            this.LED117.Image = ((System.Drawing.Image)(resources.GetObject("LED117.Image")));
            this.LED117.Location = new System.Drawing.Point(534, 116);
            this.LED117.Name = "LED117";
            this.LED117.Size = new System.Drawing.Size(30, 30);
            this.LED117.TabIndex = 141;
            this.LED117.TabStop = false;
            this.LED117.Tag = "A";
            this.LED117.Click += new System.EventHandler(this.LED117_Click);
            // 
            // LED18
            // 
            this.LED18.Image = ((System.Drawing.Image)(resources.GetObject("LED18.Image")));
            this.LED18.Location = new System.Drawing.Point(78, 230);
            this.LED18.Name = "LED18";
            this.LED18.Size = new System.Drawing.Size(30, 30);
            this.LED18.TabIndex = 54;
            this.LED18.TabStop = false;
            this.LED18.Tag = "A";
            this.LED18.Click += new System.EventHandler(this.LED18_Click);
            // 
            // LED116
            // 
            this.LED116.Image = ((System.Drawing.Image)(resources.GetObject("LED116.Image")));
            this.LED116.Location = new System.Drawing.Point(534, 154);
            this.LED116.Name = "LED116";
            this.LED116.Size = new System.Drawing.Size(30, 30);
            this.LED116.TabIndex = 140;
            this.LED116.TabStop = false;
            this.LED116.Tag = "A";
            this.LED116.Click += new System.EventHandler(this.LED116_Click);
            // 
            // LED19
            // 
            this.LED19.Image = ((System.Drawing.Image)(resources.GetObject("LED19.Image")));
            this.LED19.Location = new System.Drawing.Point(78, 192);
            this.LED19.Name = "LED19";
            this.LED19.Size = new System.Drawing.Size(30, 30);
            this.LED19.TabIndex = 55;
            this.LED19.TabStop = false;
            this.LED19.Tag = "A";
            this.LED19.Click += new System.EventHandler(this.LED19_Click);
            // 
            // LED115
            // 
            this.LED115.Image = ((System.Drawing.Image)(resources.GetObject("LED115.Image")));
            this.LED115.Location = new System.Drawing.Point(534, 192);
            this.LED115.Name = "LED115";
            this.LED115.Size = new System.Drawing.Size(30, 30);
            this.LED115.TabIndex = 139;
            this.LED115.TabStop = false;
            this.LED115.Tag = "A";
            this.LED115.Click += new System.EventHandler(this.LED115_Click);
            // 
            // LED20
            // 
            this.LED20.Image = ((System.Drawing.Image)(resources.GetObject("LED20.Image")));
            this.LED20.Location = new System.Drawing.Point(78, 154);
            this.LED20.Name = "LED20";
            this.LED20.Size = new System.Drawing.Size(30, 30);
            this.LED20.TabIndex = 56;
            this.LED20.TabStop = false;
            this.LED20.Tag = "A";
            this.LED20.Click += new System.EventHandler(this.LED20_Click);
            // 
            // LED114
            // 
            this.LED114.Image = ((System.Drawing.Image)(resources.GetObject("LED114.Image")));
            this.LED114.Location = new System.Drawing.Point(534, 230);
            this.LED114.Name = "LED114";
            this.LED114.Size = new System.Drawing.Size(30, 30);
            this.LED114.TabIndex = 138;
            this.LED114.TabStop = false;
            this.LED114.Tag = "A";
            this.LED114.Click += new System.EventHandler(this.LED114_Click);
            // 
            // LED21
            // 
            this.LED21.Image = ((System.Drawing.Image)(resources.GetObject("LED21.Image")));
            this.LED21.Location = new System.Drawing.Point(78, 116);
            this.LED21.Name = "LED21";
            this.LED21.Size = new System.Drawing.Size(30, 30);
            this.LED21.TabIndex = 57;
            this.LED21.TabStop = false;
            this.LED21.Tag = "A";
            this.LED21.Click += new System.EventHandler(this.LED21_Click);
            // 
            // LED112
            // 
            this.LED112.Image = ((System.Drawing.Image)(resources.GetObject("LED112.Image")));
            this.LED112.Location = new System.Drawing.Point(496, 2);
            this.LED112.Name = "LED112";
            this.LED112.Size = new System.Drawing.Size(30, 30);
            this.LED112.TabIndex = 137;
            this.LED112.TabStop = false;
            this.LED112.Tag = "A";
            this.LED112.Click += new System.EventHandler(this.LED112_Click);
            // 
            // LED22
            // 
            this.LED22.Image = ((System.Drawing.Image)(resources.GetObject("LED22.Image")));
            this.LED22.Location = new System.Drawing.Point(78, 78);
            this.LED22.Name = "LED22";
            this.LED22.Size = new System.Drawing.Size(30, 30);
            this.LED22.TabIndex = 58;
            this.LED22.TabStop = false;
            this.LED22.Tag = "A";
            this.LED22.Click += new System.EventHandler(this.LED22_Click);
            // 
            // LED111
            // 
            this.LED111.Image = ((System.Drawing.Image)(resources.GetObject("LED111.Image")));
            this.LED111.Location = new System.Drawing.Point(496, 40);
            this.LED111.Name = "LED111";
            this.LED111.Size = new System.Drawing.Size(30, 30);
            this.LED111.TabIndex = 136;
            this.LED111.TabStop = false;
            this.LED111.Tag = "A";
            this.LED111.Click += new System.EventHandler(this.LED111_Click);
            // 
            // LED23
            // 
            this.LED23.Image = ((System.Drawing.Image)(resources.GetObject("LED23.Image")));
            this.LED23.Location = new System.Drawing.Point(78, 40);
            this.LED23.Name = "LED23";
            this.LED23.Size = new System.Drawing.Size(30, 30);
            this.LED23.TabIndex = 59;
            this.LED23.TabStop = false;
            this.LED23.Tag = "A";
            this.LED23.Click += new System.EventHandler(this.LED23_Click);
            // 
            // LED110
            // 
            this.LED110.Image = ((System.Drawing.Image)(resources.GetObject("LED110.Image")));
            this.LED110.Location = new System.Drawing.Point(496, 78);
            this.LED110.Name = "LED110";
            this.LED110.Size = new System.Drawing.Size(30, 30);
            this.LED110.TabIndex = 135;
            this.LED110.TabStop = false;
            this.LED110.Tag = "A";
            this.LED110.Click += new System.EventHandler(this.LED110_Click);
            // 
            // LED24
            // 
            this.LED24.Image = ((System.Drawing.Image)(resources.GetObject("LED24.Image")));
            this.LED24.Location = new System.Drawing.Point(78, 2);
            this.LED24.Name = "LED24";
            this.LED24.Size = new System.Drawing.Size(30, 30);
            this.LED24.TabIndex = 60;
            this.LED24.TabStop = false;
            this.LED24.Tag = "A";
            this.LED24.Click += new System.EventHandler(this.LED24_Click);
            // 
            // LED109
            // 
            this.LED109.Image = ((System.Drawing.Image)(resources.GetObject("LED109.Image")));
            this.LED109.Location = new System.Drawing.Point(496, 116);
            this.LED109.Name = "LED109";
            this.LED109.Size = new System.Drawing.Size(30, 30);
            this.LED109.TabIndex = 134;
            this.LED109.TabStop = false;
            this.LED109.Tag = "A";
            this.LED109.Click += new System.EventHandler(this.LED109_Click);
            // 
            // LED26
            // 
            this.LED26.Image = ((System.Drawing.Image)(resources.GetObject("LED26.Image")));
            this.LED26.Location = new System.Drawing.Point(116, 230);
            this.LED26.Name = "LED26";
            this.LED26.Size = new System.Drawing.Size(30, 30);
            this.LED26.TabIndex = 61;
            this.LED26.TabStop = false;
            this.LED26.Tag = "A";
            this.LED26.Click += new System.EventHandler(this.LED26_Click);
            // 
            // LED108
            // 
            this.LED108.Image = ((System.Drawing.Image)(resources.GetObject("LED108.Image")));
            this.LED108.Location = new System.Drawing.Point(496, 154);
            this.LED108.Name = "LED108";
            this.LED108.Size = new System.Drawing.Size(30, 30);
            this.LED108.TabIndex = 133;
            this.LED108.TabStop = false;
            this.LED108.Tag = "A";
            this.LED108.Click += new System.EventHandler(this.LED108_Click);
            // 
            // LED27
            // 
            this.LED27.Image = ((System.Drawing.Image)(resources.GetObject("LED27.Image")));
            this.LED27.Location = new System.Drawing.Point(116, 192);
            this.LED27.Name = "LED27";
            this.LED27.Size = new System.Drawing.Size(30, 30);
            this.LED27.TabIndex = 62;
            this.LED27.TabStop = false;
            this.LED27.Tag = "A";
            this.LED27.Click += new System.EventHandler(this.LED27_Click);
            // 
            // LED107
            // 
            this.LED107.Image = ((System.Drawing.Image)(resources.GetObject("LED107.Image")));
            this.LED107.Location = new System.Drawing.Point(496, 192);
            this.LED107.Name = "LED107";
            this.LED107.Size = new System.Drawing.Size(30, 30);
            this.LED107.TabIndex = 132;
            this.LED107.TabStop = false;
            this.LED107.Tag = "A";
            this.LED107.Click += new System.EventHandler(this.LED107_Click);
            // 
            // LED28
            // 
            this.LED28.Image = ((System.Drawing.Image)(resources.GetObject("LED28.Image")));
            this.LED28.Location = new System.Drawing.Point(116, 154);
            this.LED28.Name = "LED28";
            this.LED28.Size = new System.Drawing.Size(30, 30);
            this.LED28.TabIndex = 63;
            this.LED28.TabStop = false;
            this.LED28.Tag = "A";
            this.LED28.Click += new System.EventHandler(this.LED28_Click);
            // 
            // LED106
            // 
            this.LED106.Image = ((System.Drawing.Image)(resources.GetObject("LED106.Image")));
            this.LED106.Location = new System.Drawing.Point(496, 230);
            this.LED106.Name = "LED106";
            this.LED106.Size = new System.Drawing.Size(30, 30);
            this.LED106.TabIndex = 131;
            this.LED106.TabStop = false;
            this.LED106.Tag = "A";
            this.LED106.Click += new System.EventHandler(this.LED106_Click);
            // 
            // LED29
            // 
            this.LED29.Image = ((System.Drawing.Image)(resources.GetObject("LED29.Image")));
            this.LED29.Location = new System.Drawing.Point(116, 116);
            this.LED29.Name = "LED29";
            this.LED29.Size = new System.Drawing.Size(30, 30);
            this.LED29.TabIndex = 64;
            this.LED29.TabStop = false;
            this.LED29.Tag = "A";
            this.LED29.Click += new System.EventHandler(this.LED29_Click);
            // 
            // LED104
            // 
            this.LED104.Image = ((System.Drawing.Image)(resources.GetObject("LED104.Image")));
            this.LED104.Location = new System.Drawing.Point(458, 2);
            this.LED104.Name = "LED104";
            this.LED104.Size = new System.Drawing.Size(30, 30);
            this.LED104.TabIndex = 130;
            this.LED104.TabStop = false;
            this.LED104.Tag = "A";
            this.LED104.Click += new System.EventHandler(this.LED104_Click);
            // 
            // LED30
            // 
            this.LED30.Image = ((System.Drawing.Image)(resources.GetObject("LED30.Image")));
            this.LED30.Location = new System.Drawing.Point(116, 78);
            this.LED30.Name = "LED30";
            this.LED30.Size = new System.Drawing.Size(30, 30);
            this.LED30.TabIndex = 65;
            this.LED30.TabStop = false;
            this.LED30.Tag = "A";
            this.LED30.Click += new System.EventHandler(this.LED30_Click);
            // 
            // LED103
            // 
            this.LED103.Image = ((System.Drawing.Image)(resources.GetObject("LED103.Image")));
            this.LED103.Location = new System.Drawing.Point(458, 40);
            this.LED103.Name = "LED103";
            this.LED103.Size = new System.Drawing.Size(30, 30);
            this.LED103.TabIndex = 129;
            this.LED103.TabStop = false;
            this.LED103.Tag = "A";
            this.LED103.Click += new System.EventHandler(this.LED103_Click);
            // 
            // LED31
            // 
            this.LED31.Image = ((System.Drawing.Image)(resources.GetObject("LED31.Image")));
            this.LED31.Location = new System.Drawing.Point(116, 40);
            this.LED31.Name = "LED31";
            this.LED31.Size = new System.Drawing.Size(30, 30);
            this.LED31.TabIndex = 66;
            this.LED31.TabStop = false;
            this.LED31.Tag = "A";
            this.LED31.Click += new System.EventHandler(this.LED31_Click);
            // 
            // LED102
            // 
            this.LED102.Image = ((System.Drawing.Image)(resources.GetObject("LED102.Image")));
            this.LED102.Location = new System.Drawing.Point(458, 78);
            this.LED102.Name = "LED102";
            this.LED102.Size = new System.Drawing.Size(30, 30);
            this.LED102.TabIndex = 128;
            this.LED102.TabStop = false;
            this.LED102.Tag = "A";
            this.LED102.Click += new System.EventHandler(this.LED102_Click);
            // 
            // LED32
            // 
            this.LED32.Image = ((System.Drawing.Image)(resources.GetObject("LED32.Image")));
            this.LED32.Location = new System.Drawing.Point(116, 2);
            this.LED32.Name = "LED32";
            this.LED32.Size = new System.Drawing.Size(30, 30);
            this.LED32.TabIndex = 67;
            this.LED32.TabStop = false;
            this.LED32.Tag = "A";
            this.LED32.Click += new System.EventHandler(this.LED32_Click);
            // 
            // LED101
            // 
            this.LED101.Image = ((System.Drawing.Image)(resources.GetObject("LED101.Image")));
            this.LED101.Location = new System.Drawing.Point(458, 116);
            this.LED101.Name = "LED101";
            this.LED101.Size = new System.Drawing.Size(30, 30);
            this.LED101.TabIndex = 127;
            this.LED101.TabStop = false;
            this.LED101.Tag = "A";
            this.LED101.Click += new System.EventHandler(this.LED101_Click);
            // 
            // LED34
            // 
            this.LED34.Image = ((System.Drawing.Image)(resources.GetObject("LED34.Image")));
            this.LED34.Location = new System.Drawing.Point(154, 230);
            this.LED34.Name = "LED34";
            this.LED34.Size = new System.Drawing.Size(30, 30);
            this.LED34.TabIndex = 68;
            this.LED34.TabStop = false;
            this.LED34.Tag = "A";
            this.LED34.Click += new System.EventHandler(this.LED34_Click);
            // 
            // LED100
            // 
            this.LED100.Image = ((System.Drawing.Image)(resources.GetObject("LED100.Image")));
            this.LED100.Location = new System.Drawing.Point(458, 154);
            this.LED100.Name = "LED100";
            this.LED100.Size = new System.Drawing.Size(30, 30);
            this.LED100.TabIndex = 126;
            this.LED100.TabStop = false;
            this.LED100.Tag = "A";
            this.LED100.Click += new System.EventHandler(this.LED100_Click);
            // 
            // LED35
            // 
            this.LED35.Image = ((System.Drawing.Image)(resources.GetObject("LED35.Image")));
            this.LED35.Location = new System.Drawing.Point(154, 192);
            this.LED35.Name = "LED35";
            this.LED35.Size = new System.Drawing.Size(30, 30);
            this.LED35.TabIndex = 69;
            this.LED35.TabStop = false;
            this.LED35.Tag = "A";
            this.LED35.Click += new System.EventHandler(this.LED35_Click);
            // 
            // LED99
            // 
            this.LED99.Image = ((System.Drawing.Image)(resources.GetObject("LED99.Image")));
            this.LED99.Location = new System.Drawing.Point(458, 192);
            this.LED99.Name = "LED99";
            this.LED99.Size = new System.Drawing.Size(30, 30);
            this.LED99.TabIndex = 125;
            this.LED99.TabStop = false;
            this.LED99.Tag = "A";
            this.LED99.Click += new System.EventHandler(this.LED99_Click);
            // 
            // LED36
            // 
            this.LED36.Image = ((System.Drawing.Image)(resources.GetObject("LED36.Image")));
            this.LED36.Location = new System.Drawing.Point(154, 154);
            this.LED36.Name = "LED36";
            this.LED36.Size = new System.Drawing.Size(30, 30);
            this.LED36.TabIndex = 70;
            this.LED36.TabStop = false;
            this.LED36.Tag = "A";
            this.LED36.Click += new System.EventHandler(this.LED36_Click);
            // 
            // LED98
            // 
            this.LED98.Image = ((System.Drawing.Image)(resources.GetObject("LED98.Image")));
            this.LED98.Location = new System.Drawing.Point(458, 230);
            this.LED98.Name = "LED98";
            this.LED98.Size = new System.Drawing.Size(30, 30);
            this.LED98.TabIndex = 124;
            this.LED98.TabStop = false;
            this.LED98.Tag = "A";
            this.LED98.Click += new System.EventHandler(this.LED98_Click);
            // 
            // LED37
            // 
            this.LED37.Image = ((System.Drawing.Image)(resources.GetObject("LED37.Image")));
            this.LED37.Location = new System.Drawing.Point(154, 116);
            this.LED37.Name = "LED37";
            this.LED37.Size = new System.Drawing.Size(30, 30);
            this.LED37.TabIndex = 71;
            this.LED37.TabStop = false;
            this.LED37.Tag = "A";
            this.LED37.Click += new System.EventHandler(this.LED37_Click);
            // 
            // LED96
            // 
            this.LED96.Image = ((System.Drawing.Image)(resources.GetObject("LED96.Image")));
            this.LED96.Location = new System.Drawing.Point(420, 2);
            this.LED96.Name = "LED96";
            this.LED96.Size = new System.Drawing.Size(30, 30);
            this.LED96.TabIndex = 123;
            this.LED96.TabStop = false;
            this.LED96.Tag = "A";
            this.LED96.Click += new System.EventHandler(this.LED96_Click);
            // 
            // LED38
            // 
            this.LED38.Image = ((System.Drawing.Image)(resources.GetObject("LED38.Image")));
            this.LED38.Location = new System.Drawing.Point(154, 78);
            this.LED38.Name = "LED38";
            this.LED38.Size = new System.Drawing.Size(30, 30);
            this.LED38.TabIndex = 72;
            this.LED38.TabStop = false;
            this.LED38.Tag = "A";
            this.LED38.Click += new System.EventHandler(this.LED38_Click);
            // 
            // LED95
            // 
            this.LED95.Image = ((System.Drawing.Image)(resources.GetObject("LED95.Image")));
            this.LED95.Location = new System.Drawing.Point(420, 40);
            this.LED95.Name = "LED95";
            this.LED95.Size = new System.Drawing.Size(30, 30);
            this.LED95.TabIndex = 122;
            this.LED95.TabStop = false;
            this.LED95.Tag = "A";
            this.LED95.Click += new System.EventHandler(this.LED95_Click);
            // 
            // LED39
            // 
            this.LED39.Image = ((System.Drawing.Image)(resources.GetObject("LED39.Image")));
            this.LED39.Location = new System.Drawing.Point(154, 40);
            this.LED39.Name = "LED39";
            this.LED39.Size = new System.Drawing.Size(30, 30);
            this.LED39.TabIndex = 73;
            this.LED39.TabStop = false;
            this.LED39.Tag = "A";
            this.LED39.Click += new System.EventHandler(this.LED39_Click);
            // 
            // LED94
            // 
            this.LED94.Image = ((System.Drawing.Image)(resources.GetObject("LED94.Image")));
            this.LED94.Location = new System.Drawing.Point(420, 78);
            this.LED94.Name = "LED94";
            this.LED94.Size = new System.Drawing.Size(30, 30);
            this.LED94.TabIndex = 121;
            this.LED94.TabStop = false;
            this.LED94.Tag = "A";
            this.LED94.Click += new System.EventHandler(this.LED94_Click);
            // 
            // LED40
            // 
            this.LED40.Image = ((System.Drawing.Image)(resources.GetObject("LED40.Image")));
            this.LED40.Location = new System.Drawing.Point(154, 2);
            this.LED40.Name = "LED40";
            this.LED40.Size = new System.Drawing.Size(30, 30);
            this.LED40.TabIndex = 74;
            this.LED40.TabStop = false;
            this.LED40.Tag = "A";
            this.LED40.Click += new System.EventHandler(this.LED40_Click);
            // 
            // LED93
            // 
            this.LED93.Image = ((System.Drawing.Image)(resources.GetObject("LED93.Image")));
            this.LED93.Location = new System.Drawing.Point(420, 116);
            this.LED93.Name = "LED93";
            this.LED93.Size = new System.Drawing.Size(30, 30);
            this.LED93.TabIndex = 120;
            this.LED93.TabStop = false;
            this.LED93.Tag = "A";
            this.LED93.Click += new System.EventHandler(this.LED93_Click);
            // 
            // LED42
            // 
            this.LED42.Image = ((System.Drawing.Image)(resources.GetObject("LED42.Image")));
            this.LED42.Location = new System.Drawing.Point(192, 230);
            this.LED42.Name = "LED42";
            this.LED42.Size = new System.Drawing.Size(30, 30);
            this.LED42.TabIndex = 75;
            this.LED42.TabStop = false;
            this.LED42.Tag = "A";
            this.LED42.Click += new System.EventHandler(this.LED42_Click);
            // 
            // LED92
            // 
            this.LED92.Image = ((System.Drawing.Image)(resources.GetObject("LED92.Image")));
            this.LED92.Location = new System.Drawing.Point(420, 154);
            this.LED92.Name = "LED92";
            this.LED92.Size = new System.Drawing.Size(30, 30);
            this.LED92.TabIndex = 119;
            this.LED92.TabStop = false;
            this.LED92.Tag = "A";
            this.LED92.Click += new System.EventHandler(this.LED92_Click);
            // 
            // LED43
            // 
            this.LED43.Image = ((System.Drawing.Image)(resources.GetObject("LED43.Image")));
            this.LED43.Location = new System.Drawing.Point(192, 192);
            this.LED43.Name = "LED43";
            this.LED43.Size = new System.Drawing.Size(30, 30);
            this.LED43.TabIndex = 76;
            this.LED43.TabStop = false;
            this.LED43.Tag = "A";
            this.LED43.Click += new System.EventHandler(this.LED43_Click);
            // 
            // LED91
            // 
            this.LED91.Image = ((System.Drawing.Image)(resources.GetObject("LED91.Image")));
            this.LED91.Location = new System.Drawing.Point(420, 192);
            this.LED91.Name = "LED91";
            this.LED91.Size = new System.Drawing.Size(30, 30);
            this.LED91.TabIndex = 118;
            this.LED91.TabStop = false;
            this.LED91.Tag = "A";
            this.LED91.Click += new System.EventHandler(this.LED91_Click);
            // 
            // LED44
            // 
            this.LED44.Image = ((System.Drawing.Image)(resources.GetObject("LED44.Image")));
            this.LED44.Location = new System.Drawing.Point(192, 154);
            this.LED44.Name = "LED44";
            this.LED44.Size = new System.Drawing.Size(30, 30);
            this.LED44.TabIndex = 77;
            this.LED44.TabStop = false;
            this.LED44.Tag = "A";
            this.LED44.Click += new System.EventHandler(this.LED44_Click);
            // 
            // LED90
            // 
            this.LED90.Image = ((System.Drawing.Image)(resources.GetObject("LED90.Image")));
            this.LED90.Location = new System.Drawing.Point(420, 230);
            this.LED90.Name = "LED90";
            this.LED90.Size = new System.Drawing.Size(30, 30);
            this.LED90.TabIndex = 117;
            this.LED90.TabStop = false;
            this.LED90.Tag = "A";
            this.LED90.Click += new System.EventHandler(this.LED90_Click);
            // 
            // LED45
            // 
            this.LED45.Image = ((System.Drawing.Image)(resources.GetObject("LED45.Image")));
            this.LED45.Location = new System.Drawing.Point(192, 116);
            this.LED45.Name = "LED45";
            this.LED45.Size = new System.Drawing.Size(30, 30);
            this.LED45.TabIndex = 78;
            this.LED45.TabStop = false;
            this.LED45.Tag = "A";
            this.LED45.Click += new System.EventHandler(this.LED45_Click);
            // 
            // LED88
            // 
            this.LED88.Image = ((System.Drawing.Image)(resources.GetObject("LED88.Image")));
            this.LED88.Location = new System.Drawing.Point(382, 2);
            this.LED88.Name = "LED88";
            this.LED88.Size = new System.Drawing.Size(30, 30);
            this.LED88.TabIndex = 116;
            this.LED88.TabStop = false;
            this.LED88.Tag = "A";
            this.LED88.Click += new System.EventHandler(this.LED88_Click);
            // 
            // LED46
            // 
            this.LED46.Image = ((System.Drawing.Image)(resources.GetObject("LED46.Image")));
            this.LED46.Location = new System.Drawing.Point(192, 78);
            this.LED46.Name = "LED46";
            this.LED46.Size = new System.Drawing.Size(30, 30);
            this.LED46.TabIndex = 79;
            this.LED46.TabStop = false;
            this.LED46.Tag = "A";
            this.LED46.Click += new System.EventHandler(this.LED46_Click);
            // 
            // LED87
            // 
            this.LED87.Image = ((System.Drawing.Image)(resources.GetObject("LED87.Image")));
            this.LED87.Location = new System.Drawing.Point(382, 40);
            this.LED87.Name = "LED87";
            this.LED87.Size = new System.Drawing.Size(30, 30);
            this.LED87.TabIndex = 115;
            this.LED87.TabStop = false;
            this.LED87.Tag = "A";
            this.LED87.Click += new System.EventHandler(this.LED87_Click);
            // 
            // LED47
            // 
            this.LED47.Image = ((System.Drawing.Image)(resources.GetObject("LED47.Image")));
            this.LED47.Location = new System.Drawing.Point(192, 40);
            this.LED47.Name = "LED47";
            this.LED47.Size = new System.Drawing.Size(30, 30);
            this.LED47.TabIndex = 80;
            this.LED47.TabStop = false;
            this.LED47.Tag = "A";
            this.LED47.Click += new System.EventHandler(this.LED47_Click);
            // 
            // LED86
            // 
            this.LED86.Image = ((System.Drawing.Image)(resources.GetObject("LED86.Image")));
            this.LED86.Location = new System.Drawing.Point(382, 78);
            this.LED86.Name = "LED86";
            this.LED86.Size = new System.Drawing.Size(30, 30);
            this.LED86.TabIndex = 114;
            this.LED86.TabStop = false;
            this.LED86.Tag = "A";
            this.LED86.Click += new System.EventHandler(this.LED86_Click);
            // 
            // LED48
            // 
            this.LED48.Image = ((System.Drawing.Image)(resources.GetObject("LED48.Image")));
            this.LED48.Location = new System.Drawing.Point(192, 2);
            this.LED48.Name = "LED48";
            this.LED48.Size = new System.Drawing.Size(30, 30);
            this.LED48.TabIndex = 81;
            this.LED48.TabStop = false;
            this.LED48.Tag = "A";
            this.LED48.Click += new System.EventHandler(this.LED48_Click);
            // 
            // LED85
            // 
            this.LED85.Image = ((System.Drawing.Image)(resources.GetObject("LED85.Image")));
            this.LED85.Location = new System.Drawing.Point(382, 116);
            this.LED85.Name = "LED85";
            this.LED85.Size = new System.Drawing.Size(30, 30);
            this.LED85.TabIndex = 113;
            this.LED85.TabStop = false;
            this.LED85.Tag = "A";
            this.LED85.Click += new System.EventHandler(this.LED85_Click);
            // 
            // LED50
            // 
            this.LED50.Image = ((System.Drawing.Image)(resources.GetObject("LED50.Image")));
            this.LED50.Location = new System.Drawing.Point(230, 230);
            this.LED50.Name = "LED50";
            this.LED50.Size = new System.Drawing.Size(30, 30);
            this.LED50.TabIndex = 82;
            this.LED50.TabStop = false;
            this.LED50.Tag = "A";
            this.LED50.Click += new System.EventHandler(this.LED50_Click);
            // 
            // LED84
            // 
            this.LED84.Image = ((System.Drawing.Image)(resources.GetObject("LED84.Image")));
            this.LED84.Location = new System.Drawing.Point(382, 154);
            this.LED84.Name = "LED84";
            this.LED84.Size = new System.Drawing.Size(30, 30);
            this.LED84.TabIndex = 112;
            this.LED84.TabStop = false;
            this.LED84.Tag = "A";
            this.LED84.Click += new System.EventHandler(this.LED84_Click);
            // 
            // LED51
            // 
            this.LED51.Image = ((System.Drawing.Image)(resources.GetObject("LED51.Image")));
            this.LED51.Location = new System.Drawing.Point(230, 192);
            this.LED51.Name = "LED51";
            this.LED51.Size = new System.Drawing.Size(30, 30);
            this.LED51.TabIndex = 83;
            this.LED51.TabStop = false;
            this.LED51.Tag = "A";
            this.LED51.Click += new System.EventHandler(this.LED51_Click);
            // 
            // LED83
            // 
            this.LED83.Image = ((System.Drawing.Image)(resources.GetObject("LED83.Image")));
            this.LED83.Location = new System.Drawing.Point(382, 192);
            this.LED83.Name = "LED83";
            this.LED83.Size = new System.Drawing.Size(30, 30);
            this.LED83.TabIndex = 111;
            this.LED83.TabStop = false;
            this.LED83.Tag = "A";
            this.LED83.Click += new System.EventHandler(this.LED83_Click);
            // 
            // LED52
            // 
            this.LED52.Image = ((System.Drawing.Image)(resources.GetObject("LED52.Image")));
            this.LED52.Location = new System.Drawing.Point(230, 154);
            this.LED52.Name = "LED52";
            this.LED52.Size = new System.Drawing.Size(30, 30);
            this.LED52.TabIndex = 84;
            this.LED52.TabStop = false;
            this.LED52.Tag = "A";
            this.LED52.Click += new System.EventHandler(this.LED52_Click);
            // 
            // LED82
            // 
            this.LED82.Image = ((System.Drawing.Image)(resources.GetObject("LED82.Image")));
            this.LED82.Location = new System.Drawing.Point(382, 230);
            this.LED82.Name = "LED82";
            this.LED82.Size = new System.Drawing.Size(30, 30);
            this.LED82.TabIndex = 110;
            this.LED82.TabStop = false;
            this.LED82.Tag = "A";
            this.LED82.Click += new System.EventHandler(this.LED82_Click);
            // 
            // LED53
            // 
            this.LED53.Image = ((System.Drawing.Image)(resources.GetObject("LED53.Image")));
            this.LED53.Location = new System.Drawing.Point(230, 116);
            this.LED53.Name = "LED53";
            this.LED53.Size = new System.Drawing.Size(30, 30);
            this.LED53.TabIndex = 85;
            this.LED53.TabStop = false;
            this.LED53.Tag = "A";
            this.LED53.Click += new System.EventHandler(this.LED53_Click);
            // 
            // LED80
            // 
            this.LED80.Image = ((System.Drawing.Image)(resources.GetObject("LED80.Image")));
            this.LED80.Location = new System.Drawing.Point(344, 2);
            this.LED80.Name = "LED80";
            this.LED80.Size = new System.Drawing.Size(30, 30);
            this.LED80.TabIndex = 109;
            this.LED80.TabStop = false;
            this.LED80.Tag = "A";
            this.LED80.Click += new System.EventHandler(this.LED80_Click);
            // 
            // LED54
            // 
            this.LED54.Image = ((System.Drawing.Image)(resources.GetObject("LED54.Image")));
            this.LED54.Location = new System.Drawing.Point(230, 78);
            this.LED54.Name = "LED54";
            this.LED54.Size = new System.Drawing.Size(30, 30);
            this.LED54.TabIndex = 86;
            this.LED54.TabStop = false;
            this.LED54.Tag = "A";
            this.LED54.Click += new System.EventHandler(this.LED54_Click);
            // 
            // LED79
            // 
            this.LED79.Image = ((System.Drawing.Image)(resources.GetObject("LED79.Image")));
            this.LED79.Location = new System.Drawing.Point(344, 40);
            this.LED79.Name = "LED79";
            this.LED79.Size = new System.Drawing.Size(30, 30);
            this.LED79.TabIndex = 108;
            this.LED79.TabStop = false;
            this.LED79.Tag = "A";
            this.LED79.Click += new System.EventHandler(this.LED79_Click);
            // 
            // LED55
            // 
            this.LED55.Image = ((System.Drawing.Image)(resources.GetObject("LED55.Image")));
            this.LED55.Location = new System.Drawing.Point(230, 40);
            this.LED55.Name = "LED55";
            this.LED55.Size = new System.Drawing.Size(30, 30);
            this.LED55.TabIndex = 87;
            this.LED55.TabStop = false;
            this.LED55.Tag = "A";
            this.LED55.Click += new System.EventHandler(this.LED55_Click);
            // 
            // LED78
            // 
            this.LED78.Image = ((System.Drawing.Image)(resources.GetObject("LED78.Image")));
            this.LED78.Location = new System.Drawing.Point(344, 78);
            this.LED78.Name = "LED78";
            this.LED78.Size = new System.Drawing.Size(30, 30);
            this.LED78.TabIndex = 107;
            this.LED78.TabStop = false;
            this.LED78.Tag = "A";
            this.LED78.Click += new System.EventHandler(this.LED78_Click);
            // 
            // LED56
            // 
            this.LED56.Image = ((System.Drawing.Image)(resources.GetObject("LED56.Image")));
            this.LED56.Location = new System.Drawing.Point(230, 2);
            this.LED56.Name = "LED56";
            this.LED56.Size = new System.Drawing.Size(30, 30);
            this.LED56.TabIndex = 88;
            this.LED56.TabStop = false;
            this.LED56.Tag = "A";
            this.LED56.Click += new System.EventHandler(this.LED56_Click);
            // 
            // LED77
            // 
            this.LED77.Image = ((System.Drawing.Image)(resources.GetObject("LED77.Image")));
            this.LED77.Location = new System.Drawing.Point(344, 116);
            this.LED77.Name = "LED77";
            this.LED77.Size = new System.Drawing.Size(30, 30);
            this.LED77.TabIndex = 106;
            this.LED77.TabStop = false;
            this.LED77.Tag = "A";
            this.LED77.Click += new System.EventHandler(this.LED77_Click);
            // 
            // LED58
            // 
            this.LED58.Image = ((System.Drawing.Image)(resources.GetObject("LED58.Image")));
            this.LED58.Location = new System.Drawing.Point(268, 230);
            this.LED58.Name = "LED58";
            this.LED58.Size = new System.Drawing.Size(30, 30);
            this.LED58.TabIndex = 89;
            this.LED58.TabStop = false;
            this.LED58.Tag = "A";
            this.LED58.Click += new System.EventHandler(this.LED58_Click);
            // 
            // LED76
            // 
            this.LED76.Image = ((System.Drawing.Image)(resources.GetObject("LED76.Image")));
            this.LED76.Location = new System.Drawing.Point(344, 154);
            this.LED76.Name = "LED76";
            this.LED76.Size = new System.Drawing.Size(30, 30);
            this.LED76.TabIndex = 105;
            this.LED76.TabStop = false;
            this.LED76.Tag = "A";
            this.LED76.Click += new System.EventHandler(this.LED76_Click);
            // 
            // LED59
            // 
            this.LED59.Image = ((System.Drawing.Image)(resources.GetObject("LED59.Image")));
            this.LED59.Location = new System.Drawing.Point(268, 192);
            this.LED59.Name = "LED59";
            this.LED59.Size = new System.Drawing.Size(30, 30);
            this.LED59.TabIndex = 90;
            this.LED59.TabStop = false;
            this.LED59.Tag = "A";
            this.LED59.Click += new System.EventHandler(this.LED59_Click);
            // 
            // LED75
            // 
            this.LED75.Image = ((System.Drawing.Image)(resources.GetObject("LED75.Image")));
            this.LED75.Location = new System.Drawing.Point(344, 192);
            this.LED75.Name = "LED75";
            this.LED75.Size = new System.Drawing.Size(30, 30);
            this.LED75.TabIndex = 104;
            this.LED75.TabStop = false;
            this.LED75.Tag = "A";
            this.LED75.Click += new System.EventHandler(this.LED75_Click);
            // 
            // LED60
            // 
            this.LED60.Image = ((System.Drawing.Image)(resources.GetObject("LED60.Image")));
            this.LED60.Location = new System.Drawing.Point(268, 154);
            this.LED60.Name = "LED60";
            this.LED60.Size = new System.Drawing.Size(30, 30);
            this.LED60.TabIndex = 91;
            this.LED60.TabStop = false;
            this.LED60.Tag = "A";
            this.LED60.Click += new System.EventHandler(this.LED60_Click);
            // 
            // LED74
            // 
            this.LED74.Image = ((System.Drawing.Image)(resources.GetObject("LED74.Image")));
            this.LED74.Location = new System.Drawing.Point(344, 230);
            this.LED74.Name = "LED74";
            this.LED74.Size = new System.Drawing.Size(30, 30);
            this.LED74.TabIndex = 103;
            this.LED74.TabStop = false;
            this.LED74.Tag = "A";
            this.LED74.Click += new System.EventHandler(this.LED74_Click);
            // 
            // LED61
            // 
            this.LED61.Image = ((System.Drawing.Image)(resources.GetObject("LED61.Image")));
            this.LED61.Location = new System.Drawing.Point(268, 116);
            this.LED61.Name = "LED61";
            this.LED61.Size = new System.Drawing.Size(30, 30);
            this.LED61.TabIndex = 92;
            this.LED61.TabStop = false;
            this.LED61.Tag = "A";
            this.LED61.Click += new System.EventHandler(this.LED61_Click);
            // 
            // LED72
            // 
            this.LED72.Image = ((System.Drawing.Image)(resources.GetObject("LED72.Image")));
            this.LED72.Location = new System.Drawing.Point(306, 2);
            this.LED72.Name = "LED72";
            this.LED72.Size = new System.Drawing.Size(30, 30);
            this.LED72.TabIndex = 102;
            this.LED72.TabStop = false;
            this.LED72.Tag = "A";
            this.LED72.Click += new System.EventHandler(this.LED72_Click);
            // 
            // LED62
            // 
            this.LED62.Image = ((System.Drawing.Image)(resources.GetObject("LED62.Image")));
            this.LED62.Location = new System.Drawing.Point(268, 78);
            this.LED62.Name = "LED62";
            this.LED62.Size = new System.Drawing.Size(30, 30);
            this.LED62.TabIndex = 93;
            this.LED62.TabStop = false;
            this.LED62.Tag = "A";
            this.LED62.Click += new System.EventHandler(this.LED62_Click);
            // 
            // LED71
            // 
            this.LED71.Image = ((System.Drawing.Image)(resources.GetObject("LED71.Image")));
            this.LED71.Location = new System.Drawing.Point(306, 40);
            this.LED71.Name = "LED71";
            this.LED71.Size = new System.Drawing.Size(30, 30);
            this.LED71.TabIndex = 101;
            this.LED71.TabStop = false;
            this.LED71.Tag = "A";
            this.LED71.Click += new System.EventHandler(this.LED71_Click);
            // 
            // LED63
            // 
            this.LED63.Image = ((System.Drawing.Image)(resources.GetObject("LED63.Image")));
            this.LED63.Location = new System.Drawing.Point(268, 40);
            this.LED63.Name = "LED63";
            this.LED63.Size = new System.Drawing.Size(30, 30);
            this.LED63.TabIndex = 94;
            this.LED63.TabStop = false;
            this.LED63.Tag = "A";
            this.LED63.Click += new System.EventHandler(this.LED63_Click);
            // 
            // LED70
            // 
            this.LED70.Image = ((System.Drawing.Image)(resources.GetObject("LED70.Image")));
            this.LED70.Location = new System.Drawing.Point(306, 78);
            this.LED70.Name = "LED70";
            this.LED70.Size = new System.Drawing.Size(30, 30);
            this.LED70.TabIndex = 100;
            this.LED70.TabStop = false;
            this.LED70.Tag = "A";
            this.LED70.Click += new System.EventHandler(this.LED70_Click);
            // 
            // LED64
            // 
            this.LED64.Image = ((System.Drawing.Image)(resources.GetObject("LED64.Image")));
            this.LED64.Location = new System.Drawing.Point(268, 2);
            this.LED64.Name = "LED64";
            this.LED64.Size = new System.Drawing.Size(30, 30);
            this.LED64.TabIndex = 95;
            this.LED64.TabStop = false;
            this.LED64.Tag = "A";
            this.LED64.Click += new System.EventHandler(this.LED64_Click);
            // 
            // LED69
            // 
            this.LED69.Image = ((System.Drawing.Image)(resources.GetObject("LED69.Image")));
            this.LED69.Location = new System.Drawing.Point(306, 116);
            this.LED69.Name = "LED69";
            this.LED69.Size = new System.Drawing.Size(30, 30);
            this.LED69.TabIndex = 99;
            this.LED69.TabStop = false;
            this.LED69.Tag = "A";
            this.LED69.Click += new System.EventHandler(this.LED69_Click);
            // 
            // LED66
            // 
            this.LED66.Image = ((System.Drawing.Image)(resources.GetObject("LED66.Image")));
            this.LED66.Location = new System.Drawing.Point(306, 230);
            this.LED66.Name = "LED66";
            this.LED66.Size = new System.Drawing.Size(30, 30);
            this.LED66.TabIndex = 96;
            this.LED66.TabStop = false;
            this.LED66.Tag = "A";
            this.LED66.Click += new System.EventHandler(this.LED66_Click);
            // 
            // LED68
            // 
            this.LED68.Image = ((System.Drawing.Image)(resources.GetObject("LED68.Image")));
            this.LED68.Location = new System.Drawing.Point(306, 154);
            this.LED68.Name = "LED68";
            this.LED68.Size = new System.Drawing.Size(30, 30);
            this.LED68.TabIndex = 98;
            this.LED68.TabStop = false;
            this.LED68.Tag = "A";
            this.LED68.Click += new System.EventHandler(this.LED68_Click);
            // 
            // LED67
            // 
            this.LED67.Image = ((System.Drawing.Image)(resources.GetObject("LED67.Image")));
            this.LED67.Location = new System.Drawing.Point(306, 192);
            this.LED67.Name = "LED67";
            this.LED67.Size = new System.Drawing.Size(30, 30);
            this.LED67.TabIndex = 97;
            this.LED67.TabStop = false;
            this.LED67.Tag = "A";
            this.LED67.Click += new System.EventHandler(this.LED67_Click);
            // 
            // matrixBackground
            // 
            this.matrixBackground.BackColor = System.Drawing.Color.Transparent;
            this.matrixBackground.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.matrixBackground.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.matrixBackground.Image = global::_16_x_8_LED_Control.Properties.Resources.Off_Black_Background;
            this.matrixBackground.Location = new System.Drawing.Point(0, 0);
            this.matrixBackground.Name = "matrixBackground";
            this.matrixBackground.Size = new System.Drawing.Size(604, 300);
            this.matrixBackground.TabIndex = 23;
            this.matrixBackground.TabStop = false;
            // 
            // btn100ms
            // 
            this.btn100ms.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(33)))), ((int)(((byte)(45)))));
            this.btn100ms.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn100ms.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn100ms.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(63)))), ((int)(((byte)(75)))));
            this.btn100ms.Location = new System.Drawing.Point(231, 304);
            this.btn100ms.Name = "btn100ms";
            this.btn100ms.Size = new System.Drawing.Size(80, 30);
            this.btn100ms.TabIndex = 10;
            this.btn100ms.Text = "100ms";
            this.btn100ms.UseVisualStyleBackColor = false;
            this.btn100ms.Click += new System.EventHandler(this.btn100ms_Click);
            // 
            // btn1000ms
            // 
            this.btn1000ms.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(33)))), ((int)(((byte)(45)))));
            this.btn1000ms.Cursor = System.Windows.Forms.Cursors.No;
            this.btn1000ms.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn1000ms.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn1000ms.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(63)))), ((int)(((byte)(75)))));
            this.btn1000ms.Location = new System.Drawing.Point(1, 304);
            this.btn1000ms.Name = "btn1000ms";
            this.btn1000ms.Size = new System.Drawing.Size(80, 30);
            this.btn1000ms.TabIndex = 171;
            this.btn1000ms.Text = "1000ms";
            this.btn1000ms.UseVisualStyleBackColor = false;
            this.btn1000ms.Click += new System.EventHandler(this.btn1000ms_Click);
            // 
            // btn500ms
            // 
            this.btn500ms.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(33)))), ((int)(((byte)(45)))));
            this.btn500ms.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn500ms.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn500ms.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(63)))), ((int)(((byte)(75)))));
            this.btn500ms.Location = new System.Drawing.Point(79, 304);
            this.btn500ms.Name = "btn500ms";
            this.btn500ms.Size = new System.Drawing.Size(80, 30);
            this.btn500ms.TabIndex = 172;
            this.btn500ms.Text = "500ms";
            this.btn500ms.UseVisualStyleBackColor = false;
            this.btn500ms.Click += new System.EventHandler(this.btn500ms_Click);
            // 
            // btn250ms
            // 
            this.btn250ms.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(33)))), ((int)(((byte)(45)))));
            this.btn250ms.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn250ms.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn250ms.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(63)))), ((int)(((byte)(75)))));
            this.btn250ms.Location = new System.Drawing.Point(155, 304);
            this.btn250ms.Name = "btn250ms";
            this.btn250ms.Size = new System.Drawing.Size(80, 30);
            this.btn250ms.TabIndex = 173;
            this.btn250ms.Text = "200ms";
            this.btn250ms.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn250ms.UseVisualStyleBackColor = false;
            this.btn250ms.Click += new System.EventHandler(this.btn250ms_Click);
            // 
            // txtCount
            // 
            this.txtCount.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txtCount.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txtCount.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCount.ForeColor = System.Drawing.Color.Black;
            this.txtCount.Location = new System.Drawing.Point(573, 305);
            this.txtCount.Name = "txtCount";
            this.txtCount.Size = new System.Drawing.Size(30, 29);
            this.txtCount.TabIndex = 176;
            this.txtCount.Text = "0";
            this.txtCount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(43)))), ((int)(((byte)(55)))));
            this.ClientSize = new System.Drawing.Size(606, 336);
            this.Controls.Add(this.txtCount);
            this.Controls.Add(this.btn250ms);
            this.Controls.Add(this.btn500ms);
            this.Controls.Add(this.btn1000ms);
            this.Controls.Add(this.btn100ms);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.TxtFeedback);
            this.Controls.Add(this.btnConnect);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.btnSave);
            this.Name = "Form1";
            this.Text = "Animation Station";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.LED1)).EndInit();
            this.pnlSerialConnection.ResumeLayout(false);
            this.pnlSerialConnection.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LED2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED41)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED49)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED57)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED65)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED73)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED81)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED89)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED97)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED128)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED105)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED127)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED113)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED126)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED121)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED125)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED124)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED123)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED122)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED120)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED119)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED118)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED117)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED116)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED115)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED114)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED112)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED111)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED110)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED109)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED108)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED107)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED106)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED104)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED30)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED103)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED102)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED101)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED100)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED99)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED98)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED96)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED38)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED95)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED39)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED94)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED40)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED93)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED42)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED92)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED43)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED91)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED44)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED90)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED45)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED88)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED46)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED87)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED47)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED86)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED48)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED85)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED50)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED84)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED51)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED83)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED52)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED82)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED53)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED80)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED54)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED79)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED55)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED78)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED56)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED77)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED58)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED76)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED59)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED75)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED60)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED74)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED61)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED72)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED62)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED71)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED63)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED70)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED64)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED69)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED66)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED68)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LED67)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.matrixBackground)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.ComboBox ComPort;
        private System.Windows.Forms.ComboBox BaudRate;
        private System.Windows.Forms.ComboBox DataBits;
        private System.Windows.Forms.ComboBox HandShake;
        private System.Windows.Forms.Button btnConnect;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.TextBox TxtFeedback;
        private System.Windows.Forms.PictureBox matrixBackground;
        private System.Windows.Forms.PictureBox LED1;
        private System.Windows.Forms.PictureBox LED2;
        private System.Windows.Forms.PictureBox LED3;
        private System.Windows.Forms.PictureBox LED4;
        private System.Windows.Forms.PictureBox LED5;
        private System.Windows.Forms.PictureBox LED6;
        private System.Windows.Forms.PictureBox LED7;
        private System.Windows.Forms.PictureBox LED8;
        private System.Windows.Forms.PictureBox LED9;
        private System.Windows.Forms.PictureBox LED17;
        private System.Windows.Forms.PictureBox LED25;
        private System.Windows.Forms.PictureBox LED33;
        private System.Windows.Forms.PictureBox LED41;
        private System.Windows.Forms.PictureBox LED49;
        private System.Windows.Forms.PictureBox LED57;
        private System.Windows.Forms.PictureBox LED65;
        private System.Windows.Forms.PictureBox LED73;
        private System.Windows.Forms.PictureBox LED81;
        private System.Windows.Forms.PictureBox LED89;
        private System.Windows.Forms.PictureBox LED97;
        private System.Windows.Forms.PictureBox LED105;
        private System.Windows.Forms.PictureBox LED113;
        private System.Windows.Forms.PictureBox LED121;
        private System.Windows.Forms.PictureBox LED16;
        private System.Windows.Forms.PictureBox LED15;
        private System.Windows.Forms.PictureBox LED14;
        private System.Windows.Forms.PictureBox LED13;
        private System.Windows.Forms.PictureBox LED12;
        private System.Windows.Forms.PictureBox LED11;
        private System.Windows.Forms.PictureBox LED10;
        private System.Windows.Forms.PictureBox LED24;
        private System.Windows.Forms.PictureBox LED23;
        private System.Windows.Forms.PictureBox LED22;
        private System.Windows.Forms.PictureBox LED21;
        private System.Windows.Forms.PictureBox LED20;
        private System.Windows.Forms.PictureBox LED19;
        private System.Windows.Forms.PictureBox LED18;
        private System.Windows.Forms.PictureBox LED32;
        private System.Windows.Forms.PictureBox LED31;
        private System.Windows.Forms.PictureBox LED30;
        private System.Windows.Forms.PictureBox LED29;
        private System.Windows.Forms.PictureBox LED28;
        private System.Windows.Forms.PictureBox LED27;
        private System.Windows.Forms.PictureBox LED26;
        private System.Windows.Forms.PictureBox LED40;
        private System.Windows.Forms.PictureBox LED39;
        private System.Windows.Forms.PictureBox LED38;
        private System.Windows.Forms.PictureBox LED37;
        private System.Windows.Forms.PictureBox LED36;
        private System.Windows.Forms.PictureBox LED35;
        private System.Windows.Forms.PictureBox LED34;
        private System.Windows.Forms.PictureBox LED48;
        private System.Windows.Forms.PictureBox LED47;
        private System.Windows.Forms.PictureBox LED46;
        private System.Windows.Forms.PictureBox LED45;
        private System.Windows.Forms.PictureBox LED44;
        private System.Windows.Forms.PictureBox LED43;
        private System.Windows.Forms.PictureBox LED42;
        private System.Windows.Forms.PictureBox LED56;
        private System.Windows.Forms.PictureBox LED55;
        private System.Windows.Forms.PictureBox LED54;
        private System.Windows.Forms.PictureBox LED53;
        private System.Windows.Forms.PictureBox LED52;
        private System.Windows.Forms.PictureBox LED51;
        private System.Windows.Forms.PictureBox LED50;
        private System.Windows.Forms.PictureBox LED64;
        private System.Windows.Forms.PictureBox LED63;
        private System.Windows.Forms.PictureBox LED62;
        private System.Windows.Forms.PictureBox LED61;
        private System.Windows.Forms.PictureBox LED60;
        private System.Windows.Forms.PictureBox LED59;
        private System.Windows.Forms.PictureBox LED58;
        private System.Windows.Forms.PictureBox LED72;
        private System.Windows.Forms.PictureBox LED71;
        private System.Windows.Forms.PictureBox LED70;
        private System.Windows.Forms.PictureBox LED69;
        private System.Windows.Forms.PictureBox LED68;
        private System.Windows.Forms.PictureBox LED67;
        private System.Windows.Forms.PictureBox LED66;
        private System.Windows.Forms.PictureBox LED80;
        private System.Windows.Forms.PictureBox LED79;
        private System.Windows.Forms.PictureBox LED78;
        private System.Windows.Forms.PictureBox LED77;
        private System.Windows.Forms.PictureBox LED76;
        private System.Windows.Forms.PictureBox LED75;
        private System.Windows.Forms.PictureBox LED74;
        private System.Windows.Forms.PictureBox LED88;
        private System.Windows.Forms.PictureBox LED87;
        private System.Windows.Forms.PictureBox LED86;
        private System.Windows.Forms.PictureBox LED85;
        private System.Windows.Forms.PictureBox LED84;
        private System.Windows.Forms.PictureBox LED83;
        private System.Windows.Forms.PictureBox LED82;
        private System.Windows.Forms.PictureBox LED96;
        private System.Windows.Forms.PictureBox LED95;
        private System.Windows.Forms.PictureBox LED94;
        private System.Windows.Forms.PictureBox LED93;
        private System.Windows.Forms.PictureBox LED92;
        private System.Windows.Forms.PictureBox LED91;
        private System.Windows.Forms.PictureBox LED90;
        private System.Windows.Forms.PictureBox LED104;
        private System.Windows.Forms.PictureBox LED103;
        private System.Windows.Forms.PictureBox LED102;
        private System.Windows.Forms.PictureBox LED101;
        private System.Windows.Forms.PictureBox LED100;
        private System.Windows.Forms.PictureBox LED99;
        private System.Windows.Forms.PictureBox LED98;
        private System.Windows.Forms.PictureBox LED112;
        private System.Windows.Forms.PictureBox LED111;
        private System.Windows.Forms.PictureBox LED110;
        private System.Windows.Forms.PictureBox LED109;
        private System.Windows.Forms.PictureBox LED108;
        private System.Windows.Forms.PictureBox LED107;
        private System.Windows.Forms.PictureBox LED106;
        private System.Windows.Forms.PictureBox LED120;
        private System.Windows.Forms.PictureBox LED119;
        private System.Windows.Forms.PictureBox LED118;
        private System.Windows.Forms.PictureBox LED117;
        private System.Windows.Forms.PictureBox LED116;
        private System.Windows.Forms.PictureBox LED115;
        private System.Windows.Forms.PictureBox LED114;
        private System.Windows.Forms.PictureBox LED128;
        private System.Windows.Forms.PictureBox LED127;
        private System.Windows.Forms.PictureBox LED126;
        private System.Windows.Forms.PictureBox LED125;
        private System.Windows.Forms.PictureBox LED124;
        private System.Windows.Forms.PictureBox LED123;
        private System.Windows.Forms.PictureBox LED122;
        private System.Windows.Forms.ComboBox StopBits;
        private System.Windows.Forms.ComboBox Parity;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn100ms;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Button btn1000ms;
        private System.Windows.Forms.Button btn500ms;
        private System.Windows.Forms.Button btn250ms;
        private System.Windows.Forms.Panel pnlSerialConnection;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label txtCount;
    }
}

