﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.Ports;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
using System.Media;
using System.IO;

namespace _16_x_8_LED_Control
{

    public partial class Form1 : Form
    {
        Bitmap bmpGray = Properties.Resources.Gray_Circle_Transparent;
        Bitmap bmpRed = Properties.Resources.Red_Circle_Transparent;
        Bitmap bmpBlack = Properties.Resources.Off_Black_Background;
        Stream str = Properties.Resources.The_Bakery_is_Open;

        public Form1()
        {
            InitializeComponent();

            btnStart.Enabled = false;
            btnSave.Enabled = false;
            btn1000ms.Enabled = false;
            btn500ms.Enabled = false;
            btn250ms.Enabled = false;
            btn100ms.Enabled = false;
            btnStart.Cursor = Cursors.No;
            btnSave.Cursor = Cursors.No;
            btn1000ms.Cursor = Cursors.No;
            btn500ms.Cursor = Cursors.No;
            btn250ms.Cursor = Cursors.No;
            btn100ms.Cursor = Cursors.No;

            foreach (PictureBox pb in panel1.Controls.OfType<PictureBox>())
            {
                pb.Image = bmpGray;
                pb.Enabled = false;
                pb.Cursor = Cursors.Hand;
                matrixBackground.Cursor = Cursors.Default;
                matrixBackground.Image = bmpBlack;
                Helper.BlendPictures(this.matrixBackground, pb);
            }


            /*This section of code is for the Serial Port setup. Optons for Com port, baud rate,
              stop bits, parity, and handshaking have been added.*/
            string[] ArrayComPortsNames = null;
            int index = -1;
            string ComPortName = null;

            ArrayComPortsNames = SerialPort.GetPortNames();
            do
            {
                index += 1;
                ComPort.Items.Add(ArrayComPortsNames[index]);
            }
            while (!((ArrayComPortsNames[index] == ComPortName) ||
                                (index == ArrayComPortsNames.GetUpperBound(0))));

            Array.Sort(ArrayComPortsNames);

            //Combo Box for Com Ports
            if (index == ArrayComPortsNames.GetUpperBound(0))
            {
                ComPortName = ArrayComPortsNames[0];
            }
            ComPort.Text = ArrayComPortsNames[0];

            //Combo Box for Baud Rate
            BaudRate.Items.Add(300);
            BaudRate.Items.Add(600);
            BaudRate.Items.Add(1200);
            BaudRate.Items.Add(2400);
            BaudRate.Items.Add(9600);
            BaudRate.Items.Add(14400);
            BaudRate.Items.Add(19200);
            BaudRate.Items.Add(38400);
            BaudRate.Items.Add(57600);
            BaudRate.Items.Add(115200);
            BaudRate.Items.ToString();
            BaudRate.Text = BaudRate.Items[0].ToString();

            //Combo Box for Data Bits
            DataBits.Items.Add(5);
            DataBits.Items.Add(6);
            DataBits.Items.Add(7);
            DataBits.Items.Add(8);
            DataBits.Items.ToString();
            DataBits.Text = DataBits.Items[0].ToString();

            //Combo Box for Handshake
            HandShake.Items.Add("None");
            HandShake.Items.Add("XOnXOff");
            HandShake.Items.Add("RequestToSend");
            HandShake.Items.Add("RequestToSendXOnXOff");

            //Combo Box for Stop Bits
            StopBits.Items.Add("One");
            StopBits.Items.Add("Two");
            StopBits.Items.Add("OnePointFive");

            //Combo Box for Parity
            Parity.Items.Add("None");
            Parity.Items.Add("Odd");
            Parity.Items.Add("Even");
            Parity.Items.Add("Mark");
            Parity.Items.Add("Space");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            serialPort1.Write("1");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            serialPort1.Write("3");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void btn100ms_Click(object sender, EventArgs e)
        {
            serialPort1.Write("{");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("q");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("{");
            TxtFeedback.Text = serialPort1.ReadLine();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            SoundPlayer player = new SoundPlayer(str);
              
            if (btnConnect.Text == "Connect")
            {
                serialPort1.PortName = Convert.ToString(ComPort.Text);
                serialPort1.BaudRate = Convert.ToInt32(BaudRate.Text);
                serialPort1.DataBits = Convert.ToInt16(DataBits.Text);
                serialPort1.StopBits = (StopBits)Enum.Parse(typeof(StopBits), StopBits.Text);
                serialPort1.Handshake = (Handshake)Enum.Parse(typeof(Handshake), HandShake.Text);
                serialPort1.Parity = (Parity)Enum.Parse(typeof(Parity), Parity.Text);


                serialPort1.Open();
                pnlSerialConnection.Visible = false;
                btnConnect.Text = "Disconnect";
                player.Play();

                foreach (PictureBox pb in panel1.Controls.OfType<PictureBox>())
                {
                    pb.Enabled = true;
                }
                
                btnStart.Enabled = true;
                btnSave.Enabled = true;
                btn1000ms.Enabled = true;
                btn500ms.Enabled = true;
                btn250ms.Enabled = true;
                btn100ms.Enabled = true;

                btnStart.Cursor = Cursors.Default;
                btnSave.Cursor = Cursors.Default;
                btn1000ms.Cursor = Cursors.Default;
                btn500ms.Cursor = Cursors.Default;
                btn250ms.Cursor = Cursors.Default;
                btn100ms.Cursor = Cursors.Default;

                pnlSerialConnection.Visible = false;
            }
            else if (btnConnect.Text == "Disconnect")
            {
                btnConnect.Text = "Connect";
                serialPort1.Close();
                foreach (PictureBox pb in panel1.Controls.OfType<PictureBox>())
                {
                    pb.Enabled = false;
                }
                btnStart.Enabled = false;
                btnStart.Enabled = false;
                btn1000ms.Enabled = false;
                btn500ms.Enabled = false;
                btn250ms.Enabled = false;
                btn100ms.Enabled = false;

                btnStart.Cursor = Cursors.No;
                btnSave.Cursor = Cursors.No;
                btn1000ms.Cursor = Cursors.No;
                btn500ms.Cursor = Cursors.No;
                btn250ms.Cursor = Cursors.No;
                btn100ms.Cursor = Cursors.No;
                pnlSerialConnection.Visible = true;

                pnlSerialConnection.Visible = true;
            }
           
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            serialPort1.Write("\r");
            foreach (PictureBox pb in panel1.Controls.OfType<PictureBox>())
            {
                pb.Image = bmpGray;
            }
            matrixBackground.Image = bmpBlack; 
            txtCount.Text = "0";

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            foreach (PictureBox pb in panel1.Controls.OfType<PictureBox>())
            {
                pb.Image = bmpGray;
            }
            matrixBackground.Image = bmpBlack;
            serialPort1.Write("\t");
            txtCount.Text = serialPort1.ReadLine();
        }
        private void LED1_Click(object sender, EventArgs e)
        {
            if (LED1.Image == bmpGray)
            {
                LED1.Image = bmpRed;
            } else if (LED1.Image == bmpRed)
            {
                LED1.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED1);
            serialPort1.Write("`");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("1");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("`");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED2_Click(object sender, EventArgs e)
        {
            if (LED2.Image == bmpGray)
            {
                LED2.Image = bmpRed;
            }
            else if (LED2.Image == bmpRed)
            {
                LED2.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED2);
            serialPort1.Write("`");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("2");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("`");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED3_Click(object sender, EventArgs e)
        {
            if (LED3.Image == bmpGray)
            {
                LED3.Image = bmpRed;
            }
            else if (LED3.Image == bmpRed)
            {
                LED3.Image = bmpGray;
            }
            serialPort1.Write("`");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("3");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("`");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED4_Click(object sender, EventArgs e)
        {
            if (LED4.Image == bmpGray)
            {
                LED4.Image = bmpRed;
            }
            else if (LED4.Image == bmpRed)
            {
                LED4.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED4);
            serialPort1.Write("`");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("4");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("`");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED5_Click(object sender, EventArgs e)
        {
            if (LED5.Image == bmpGray)
            {
                LED5.Image = bmpRed;
            }
            else if (LED5.Image == bmpRed)
            {
                LED5.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED5);
            serialPort1.Write("`");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("5");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("`");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED6_Click(object sender, EventArgs e)
        {
            if (LED6.Image == bmpGray)
            {
                LED6.Image = bmpRed;
            }
            else if (LED6.Image == bmpRed)
            {
                LED6.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED6);
            serialPort1.Write("`");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("6");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("`");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED7_Click(object sender, EventArgs e)
        {
            if (LED7.Image == bmpGray)
            {
                LED7.Image = bmpRed;
            }
            else if (LED7.Image == bmpRed)
            {
                LED7.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED7);
            serialPort1.Write("`");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("7");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("`");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED8_Click(object sender, EventArgs e)
        {
            if (LED8.Image == bmpGray)
            {
                LED8.Image = bmpRed;
            }
            else if (LED8.Image == bmpRed)
            {
                LED8.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED8);
            serialPort1.Write("`");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("8");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("`");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED9_Click(object sender, EventArgs e)
        {
            if (LED9.Image == bmpGray)
            {
                LED9.Image = bmpRed;
            }
            else if (LED9.Image == bmpRed)
            {
                LED9.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED9);
            serialPort1.Write("a");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("1");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("a");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED10_Click(object sender, EventArgs e)
        {
            if (LED10.Image == bmpGray)
            {
                LED10.Image = bmpRed;
            }
            else if (LED10.Image == bmpRed)
            {
                LED10.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED10);
            serialPort1.Write("a");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("2");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("a");
            TxtFeedback.Text = serialPort1.ReadLine();
        }
        private void LED11_Click(object sender, EventArgs e)
        {
            if (LED11.Image == bmpGray)
            {
                LED11.Image = bmpRed;
            }
            else if (LED11.Image == bmpRed)
            {
                LED11.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED11);
            serialPort1.Write("a");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("3");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("a");
            TxtFeedback.Text = serialPort1.ReadLine();
        }
        private void LED12_Click(object sender, EventArgs e)
        {
            if (LED12.Image == bmpGray)
            {
                LED12.Image = bmpRed;
            }
            else if (LED12.Image == bmpRed)
            {
                LED12.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED12);
            serialPort1.Write("a");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("4");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("a");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED13_Click(object sender, EventArgs e)
        {
            if (LED13.Image == bmpGray)
            {
                LED13.Image = bmpRed;
            }
            else if (LED13.Image == bmpRed)
            {
                LED13.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED13);
            serialPort1.Write("a");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("5");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("a");
            TxtFeedback.Text = serialPort1.ReadLine();
        }
        private void LED14_Click(object sender, EventArgs e)
        {
            if (LED14.Image == bmpGray)
            {
                LED14.Image = bmpRed;
            }
            else if (LED14.Image == bmpRed)
            {
                LED14.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED14);
            serialPort1.Write("a");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("6");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("a");
            TxtFeedback.Text = serialPort1.ReadLine();
        }
        private void LED15_Click(object sender, EventArgs e)
        {
            if (LED15.Image == bmpGray)
            {
                LED15.Image = bmpRed;
            }
            else if (LED15.Image == bmpRed)
            {
                LED15.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED15);
            serialPort1.Write("a");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("7");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("a");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED16_Click(object sender, EventArgs e)
        {
            if (LED16.Image == bmpGray)
            {
                LED16.Image = bmpRed;
            }
            else if (LED16.Image == bmpRed)
            {
                LED16.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED16);
            serialPort1.Write("a");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("8");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("a");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED17_Click(object sender, EventArgs e)
        {
            if (LED17.Image == bmpGray)
            {
                LED17.Image = bmpRed;
            }
            else if (LED17.Image == bmpRed)
            {
                LED17.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED17);
            serialPort1.Write("b");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("1");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("b");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED18_Click(object sender, EventArgs e)
        {
            if (LED18.Image == bmpGray)
            {
                LED18.Image = bmpRed;
            }
            else if (LED18.Image == bmpRed)
            {
                LED18.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED18);
            serialPort1.Write("b");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("2");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("b");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED19_Click(object sender, EventArgs e)
        {
            if (LED19.Image == bmpGray)
            {
                LED19.Image = bmpRed;
            }
            else if (LED19.Image == bmpRed)
            {
                LED19.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED19);
            serialPort1.Write("b");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("3");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("b");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED20_Click(object sender, EventArgs e)
        {
            if (LED20.Image == bmpGray)
            {
                LED20.Image = bmpRed;
            }
            else if (LED20.Image == bmpRed)
            {
                LED20.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED20);
            serialPort1.Write("b");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("4");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("b");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED21_Click(object sender, EventArgs e)
        {
            if (LED21.Image == bmpGray)
            {
                LED21.Image = bmpRed;
            }
            else if (LED21.Image == bmpRed)
            {
                LED21.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED21);
            serialPort1.Write("b");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("5");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("b");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED22_Click(object sender, EventArgs e)
        {
            if (LED22.Image == bmpGray)
            {
                LED22.Image = bmpRed;
            }
            else if (LED22.Image == bmpRed)
            {
                LED22.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED22);
            serialPort1.Write("b");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("6");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("b");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED23_Click(object sender, EventArgs e)
        {
            if (LED23.Image == bmpGray)
            {
                LED23.Image = bmpRed;
            }
            else if (LED23.Image == bmpRed)
            {
                LED23.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED23);
            serialPort1.Write("b");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("7");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("b");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED24_Click(object sender, EventArgs e)
        {
            if (LED24.Image == bmpGray)
            {
                LED24.Image = bmpRed;
            }
            else if (LED24.Image == bmpRed)
            {
                LED24.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED24);
            serialPort1.Write("b");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("8");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("b");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED25_Click(object sender, EventArgs e)
        {
            if (LED25.Image == bmpGray)
            {
                LED25.Image = bmpRed;
            }
            else if (LED25.Image == bmpRed)
            {
                LED25.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED25);
            serialPort1.Write("c");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("1");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("c");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED26_Click(object sender, EventArgs e)
        {
            if (LED26.Image == bmpGray)
            {
                LED26.Image = bmpRed;
            }
            else if (LED26.Image == bmpRed)
            {
                LED26.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED26);
            serialPort1.Write("c");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("2");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("c");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED27_Click(object sender, EventArgs e)
        {
            if (LED27.Image == bmpGray)
            {
                LED27.Image = bmpRed;
            }
            else if (LED27.Image == bmpRed)
            {
                LED27.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED27);
            serialPort1.Write("c");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("3");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("c");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED28_Click(object sender, EventArgs e)
        {
            if (LED28.Image == bmpGray)
            {
                LED28.Image = bmpRed;
            }
            else if (LED28.Image == bmpRed)
            {
                LED28.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED28);
            serialPort1.Write("c");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("4");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("c");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED29_Click(object sender, EventArgs e)
        {
            if (LED29.Image == bmpGray)
            {
                LED29.Image = bmpRed;
            }
            else if (LED29.Image == bmpRed)
            {
                LED29.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED29);
            serialPort1.Write("c");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("5");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("c");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED30_Click(object sender, EventArgs e)
        {
            if (LED30.Image == bmpGray)
            {
                LED30.Image = bmpRed;
            }
            else if (LED30.Image == bmpRed)
            {
                LED30.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED30);
            serialPort1.Write("c");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("6");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("c");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED31_Click(object sender, EventArgs e)
        {
            if (LED31.Image == bmpGray)
            {
                LED31.Image = bmpRed;
            }
            else if (LED31.Image == bmpRed)
            {
                LED31.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED31);
            serialPort1.Write("c");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("7");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("c");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED32_Click(object sender, EventArgs e)
        {
            if (LED32.Image == bmpGray)
            {
                LED32.Image = bmpRed;
            }
            else if (LED32.Image == bmpRed)
            {
                LED32.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED32);
            serialPort1.Write("c");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("8");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("c");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED33_Click(object sender, EventArgs e)
        {
            if (LED33.Image == bmpGray)
            {
                LED33.Image = bmpRed;
            }
            else if (LED33.Image == bmpRed)
            {
                LED33.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED33);
            serialPort1.Write("d");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("1");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("d");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED34_Click(object sender, EventArgs e)
        {
            if (LED34.Image == bmpGray)
            {
                LED34.Image = bmpRed;
            }
            else if (LED34.Image == bmpRed)
            {
                LED34.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED34);
            serialPort1.Write("d");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("2");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("d");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED35_Click(object sender, EventArgs e)
        {
            if (LED35.Image == bmpGray)
            {
                LED35.Image = bmpRed;
            }
            else if (LED35.Image == bmpRed)
            {
                LED35.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED35);
            serialPort1.Write("d");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("3");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("d");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED36_Click(object sender, EventArgs e)
        {
            if (LED36.Image == bmpGray)
            {
                LED36.Image = bmpRed;
            }
            else if (LED36.Image == bmpRed)
            {
                LED36.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED36);
            serialPort1.Write("d");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("4");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("d");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED37_Click(object sender, EventArgs e)
        {
            if (LED37.Image == bmpGray)
            {
                LED37.Image = bmpRed;
            }
            else if (LED37.Image == bmpRed)
            {
                LED37.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED37);
            serialPort1.Write("d");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("5");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("d");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED38_Click(object sender, EventArgs e)
        {
            if (LED38.Image == bmpGray)
            {
                LED38.Image = bmpRed;
            }
            else if (LED38.Image == bmpRed)
            {
                LED38.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED38);
            serialPort1.Write("d");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("6");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("d");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED39_Click(object sender, EventArgs e)
        {
            if (LED39.Image == bmpGray)
            {
                LED39.Image = bmpRed;
            }
            else if (LED39.Image == bmpRed)
            {
                LED39.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED39);
            serialPort1.Write("d");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("7");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("d");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED40_Click(object sender, EventArgs e)
        {
            if (LED40.Image == bmpGray)
            {
                LED40.Image = bmpRed;
            }
            else if (LED40.Image == bmpRed)
            {
                LED40.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED40);
            serialPort1.Write("d");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("8");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("d");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED41_Click(object sender, EventArgs e)
        {
            if (LED41.Image == bmpGray)
            {
                LED41.Image = bmpRed;
            }
            else if (LED41.Image == bmpRed)
            {
                LED41.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED41);
            serialPort1.Write("e");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("1");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("e");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED42_Click(object sender, EventArgs e)
        {
            if (LED42.Image == bmpGray)
            {
                LED42.Image = bmpRed;
            }
            else if (LED42.Image == bmpRed)
            {
                LED42.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED42);
            serialPort1.Write("e");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("2");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("e");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED43_Click(object sender, EventArgs e)
        {
            if (LED43.Image == bmpGray)
            {
                LED43.Image = bmpRed;
            }
            else if (LED43.Image == bmpRed)
            {
                LED43.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED43);
            serialPort1.Write("e");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("3");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("e");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED44_Click(object sender, EventArgs e)
        {
            if (LED44.Image == bmpGray)
            {
                LED44.Image = bmpRed;
            }
            else if (LED44.Image == bmpRed)
            {
                LED44.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED44);
            serialPort1.Write("e");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("4");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("e");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED45_Click(object sender, EventArgs e)
        {
            if (LED45.Image == bmpGray)
            {
                LED45.Image = bmpRed;
            }
            else if (LED45.Image == bmpRed)
            {
                LED45.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED45);
            serialPort1.Write("e");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("5");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("e");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED46_Click(object sender, EventArgs e)
        {
            if (LED46.Image == bmpGray)
            {
                LED46.Image = bmpRed;
            }
            else if (LED46.Image == bmpRed)
            {
                LED46.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED46);
            serialPort1.Write("e");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("6");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("e");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED47_Click(object sender, EventArgs e)
        {
            if (LED47.Image == bmpGray)
            {
                LED47.Image = bmpRed;
            }
            else if (LED47.Image == bmpRed)
            {
                LED47.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED47);
            serialPort1.Write("e");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("7");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("e");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED48_Click(object sender, EventArgs e)
        {
            if (LED48.Image == bmpGray)
            {
                LED48.Image = bmpRed;
            }
            else if (LED48.Image == bmpRed)
            {
                LED48.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED48);
            serialPort1.Write("e");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("8");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("e");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED49_Click(object sender, EventArgs e)
        {
            if (LED49.Image == bmpGray)
            {
                LED49.Image = bmpRed;
            }
            else if (LED49.Image == bmpRed)
            {
                LED49.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED49);
            serialPort1.Write("f");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("1");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("f");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED50_Click(object sender, EventArgs e)
        {
            if (LED50.Image == bmpGray)
            {
                LED50.Image = bmpRed;
            }
            else if (LED50.Image == bmpRed)
            {
                LED50.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED50);
            serialPort1.Write("f");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("2");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("f");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED51_Click(object sender, EventArgs e)
        {
            if (LED51.Image == bmpGray)
            {
                LED51.Image = bmpRed;
            }
            else if (LED51.Image == bmpRed)
            {
                LED51.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED51);
            serialPort1.Write("f");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("3");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("f");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED52_Click(object sender, EventArgs e)
        {
            if (LED52.Image == bmpGray)
            {
                LED52.Image = bmpRed;
            }
            else if (LED52.Image == bmpRed)
            {
                LED52.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED52);
            serialPort1.Write("f");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("4");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("f");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED53_Click(object sender, EventArgs e)
        {
            if (LED53.Image == bmpGray)
            {
                LED53.Image = bmpRed;
            }
            else if (LED53.Image == bmpRed)
            {
                LED53.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED53);
            serialPort1.Write("f");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("5");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("f");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED54_Click(object sender, EventArgs e)
        {
            if (LED54.Image == bmpGray)
            {
                LED54.Image = bmpRed;
            }
            else if (LED54.Image == bmpRed)
            {
                LED54.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED54);
            serialPort1.Write("f");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("6");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("f");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED55_Click(object sender, EventArgs e)
        {
            if (LED55.Image == bmpGray)
            {
                LED55.Image = bmpRed;
            }
            else if (LED55.Image == bmpRed)
            {
                LED55.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED55);
            serialPort1.Write("f");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("7");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("f");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED56_Click(object sender, EventArgs e)
        {
            if (LED56.Image == bmpGray)
            {
                LED56.Image = bmpRed;
            }
            else if (LED56.Image == bmpRed)
            {
                LED56.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED56);
            serialPort1.Write("f");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("8");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("f");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED57_Click(object sender, EventArgs e)
        {
            if (LED57.Image == bmpGray)
            {
                LED57.Image = bmpRed;
            }
            else if (LED57.Image == bmpRed)
            {
                LED57.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED57);
            serialPort1.Write("g");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("1");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("g");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED58_Click(object sender, EventArgs e)
        {
            if (LED58.Image == bmpGray)
            {
                LED58.Image = bmpRed;
            }
            else if (LED58.Image == bmpRed)
            {
                LED58.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED58);
            serialPort1.Write("g");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("2");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("g");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED59_Click(object sender, EventArgs e)
        {
            if (LED59.Image == bmpGray)
            {
                LED59.Image = bmpRed;
            }
            else if (LED59.Image == bmpRed)
            {
                LED59.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED59);
            serialPort1.Write("g");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("3");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("g");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED60_Click(object sender, EventArgs e)
        {
            if (LED60.Image == bmpGray)
            {
                LED60.Image = bmpRed;
            }
            else if (LED60.Image == bmpRed)
            {
                LED60.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED60);
            serialPort1.Write("g");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("4");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("g");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED61_Click(object sender, EventArgs e)
        {
            if (LED61.Image == bmpGray)
            {
                LED61.Image = bmpRed;
            }
            else if (LED61.Image == bmpRed)
            {
                LED61.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED61);
            serialPort1.Write("g");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("5");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("g");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED62_Click(object sender, EventArgs e)
        {
            if (LED62.Image == bmpGray)
            {
                LED62.Image = bmpRed;
            }
            else if (LED62.Image == bmpRed)
            {
                LED62.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED62);
            serialPort1.Write("g");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("6");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("g");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED63_Click(object sender, EventArgs e)
        {
            if (LED63.Image == bmpGray)
            {
                LED63.Image = bmpRed;
            }
            else if (LED63.Image == bmpRed)
            {
                LED63.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED63);
            serialPort1.Write("g");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("7");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("g");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED64_Click(object sender, EventArgs e)
        {
            if (LED64.Image == bmpGray)
            {
                LED64.Image = bmpRed;
            }
            else if (LED64.Image == bmpRed)
            {
                LED64.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED64);
            serialPort1.Write("g");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("8");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("g");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED65_Click(object sender, EventArgs e)
        {
            if (LED65.Image == bmpGray)
            {
                LED65.Image = bmpRed;
            }
            else if (LED65.Image == bmpRed)
            {
                LED65.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED65);
            serialPort1.Write("h");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("1");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("h");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED66_Click(object sender, EventArgs e)
        {
            if (LED66.Image == bmpGray)
            {
                LED66.Image = bmpRed;
            }
            else if (LED66.Image == bmpRed)
            {
                LED66.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED66);
            serialPort1.Write("h");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("2");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("h");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED67_Click(object sender, EventArgs e)
        {
            if (LED67.Image == bmpGray)
            {
                LED67.Image = bmpRed;
            }
            else if (LED67.Image == bmpRed)
            {
                LED67.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED67);
            serialPort1.Write("h");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("3");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("h");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED68_Click(object sender, EventArgs e)
        {
            if (LED68.Image == bmpGray)
            {
                LED68.Image = bmpRed;
            }
            else if (LED68.Image == bmpRed)
            {
                LED68.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED68);
            serialPort1.Write("h");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("4");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("h");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED69_Click(object sender, EventArgs e)
        {
            if (LED69.Image == bmpGray)
            {
                LED69.Image = bmpRed;
            }
            else if (LED69.Image == bmpRed)
            {
                LED69.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED69);
            serialPort1.Write("h");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("5");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("h");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED70_Click(object sender, EventArgs e)
        {
            if (LED70.Image == bmpGray)
            {
                LED70.Image = bmpRed;
            }
            else if (LED70.Image == bmpRed)
            {
                LED70.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED70);
            serialPort1.Write("h");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("6");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("h");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED71_Click(object sender, EventArgs e)
        {
            if (LED71.Image == bmpGray)
            {
                LED71.Image = bmpRed;
            }
            else if (LED71.Image == bmpRed)
            {
                LED71.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED71);
            serialPort1.Write("h");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("7");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("h");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED72_Click(object sender, EventArgs e)
        {
            if (LED72.Image == bmpGray)
            {
                LED72.Image = bmpRed;
            }
            else if (LED72.Image == bmpRed)
            {
                LED72.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED72);
            serialPort1.Write("h");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("8");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("h");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED73_Click(object sender, EventArgs e)
        {
            if (LED73.Image == bmpGray)
            {
                LED73.Image = bmpRed;
            }
            else if (LED73.Image == bmpRed)
            {
                LED73.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED73);
            serialPort1.Write("i");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("1");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("i");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED74_Click(object sender, EventArgs e)
        {
            if (LED74.Image == bmpGray)
            {
                LED74.Image = bmpRed;
            }
            else if (LED74.Image == bmpRed)
            {
                LED74.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED74);
            serialPort1.Write("i");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("2");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("i");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED75_Click(object sender, EventArgs e)
        {
            if (LED75.Image == bmpGray)
            {
                LED75.Image = bmpRed;
            }
            else if (LED75.Image == bmpRed)
            {
                LED75.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED75);
            serialPort1.Write("i");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("3");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("i");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED76_Click(object sender, EventArgs e)
        {
            if (LED76.Image == bmpGray)
            {
                LED76.Image = bmpRed;
            }
            else if (LED76.Image == bmpRed)
            {
                LED76.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED76);
            serialPort1.Write("i");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("4");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("i");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED77_Click(object sender, EventArgs e)
        {
            if (LED77.Image == bmpGray)
            {
                LED77.Image = bmpRed;
            }
            else if (LED77.Image == bmpRed)
            {
                LED77.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED77);
            serialPort1.Write("i");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("5");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("i");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED78_Click(object sender, EventArgs e)
        {
            if (LED78.Image == bmpGray)
            {
                LED78.Image = bmpRed;
            }
            else if (LED78.Image == bmpRed)
            {
                LED78.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED78);
            serialPort1.Write("i");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("6");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("i");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED79_Click(object sender, EventArgs e)
        {
            if (LED79.Image == bmpGray)
            {
                LED79.Image = bmpRed;
            }
            else if (LED79.Image == bmpRed)
            {
                LED79.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED79);
            serialPort1.Write("i");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("7");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("i");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED80_Click(object sender, EventArgs e)
        {
            if (LED80.Image == bmpGray)
            {
                LED80.Image = bmpRed;
            }
            else if (LED80.Image == bmpRed)
            {
                LED80.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED80);
            serialPort1.Write("i");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("8");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("i");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED81_Click(object sender, EventArgs e)
        {
            if (LED81.Image == bmpGray)
            {
                LED81.Image = bmpRed;
            }
            else if (LED81.Image == bmpRed)
            {
                LED81.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED81);
            serialPort1.Write("j");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("1");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("j");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED82_Click(object sender, EventArgs e)
        {
            if (LED82.Image == bmpGray)
            {
                LED82.Image = bmpRed;
            }
            else if (LED82.Image == bmpRed)
            {
                LED82.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED82);
            serialPort1.Write("j");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("2");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("j");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED83_Click(object sender, EventArgs e)
        {
            if (LED83.Image == bmpGray)
            {
                LED83.Image = bmpRed;
            }
            else if (LED83.Image == bmpRed)
            {
                LED83.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED83);
            serialPort1.Write("j");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("3");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("j");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED84_Click(object sender, EventArgs e)
        {
            if (LED84.Image == bmpGray)
            {
                LED84.Image = bmpRed;
            }
            else if (LED84.Image == bmpRed)
            {
                LED84.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED84);
            serialPort1.Write("j");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("4");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("j");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED85_Click(object sender, EventArgs e)
        {
            if (LED85.Image == bmpGray)
            {
                LED85.Image = bmpRed;
            }
            else if (LED85.Image == bmpRed)
            {
                LED85.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED85);
            serialPort1.Write("j");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("5");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("j");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED86_Click(object sender, EventArgs e)
        {
            if (LED86.Image == bmpGray)
            {
                LED86.Image = bmpRed;
            }
            else if (LED86.Image == bmpRed)
            {
                LED86.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED86);
            serialPort1.Write("j");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("6");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("j");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED87_Click(object sender, EventArgs e)
        {
            if (LED87.Image == bmpGray)
            {
                LED87.Image = bmpRed;
            }
            else if (LED87.Image == bmpRed)
            {
                LED87.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED87);
            serialPort1.Write("j");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("7");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("j");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED88_Click(object sender, EventArgs e)
        {
            if (LED88.Image == bmpGray)
            {
                LED88.Image = bmpRed;
            }
            else if (LED88.Image == bmpRed)
            {
                LED88.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED88);
            serialPort1.Write("j");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("8");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("j");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED89_Click(object sender, EventArgs e)
        {
            if (LED89.Image == bmpGray)
            {
                LED89.Image = bmpRed;
            }
            else if (LED89.Image == bmpRed)
            {
                LED89.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED89);
            serialPort1.Write("k");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("1");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("k");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED90_Click(object sender, EventArgs e)
        {
            if (LED90.Image == bmpGray)
            {
                LED90.Image = bmpRed;
            }
            else if (LED90.Image == bmpRed)
            {
                LED90.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED90);
            serialPort1.Write("k");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("2");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("k");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED91_Click(object sender, EventArgs e)
        {
            if (LED91.Image == bmpGray)
            {
                LED91.Image = bmpRed;
            }
            else if (LED91.Image == bmpRed)
            {
                LED91.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED91);
            serialPort1.Write("k");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("3");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("k");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED92_Click(object sender, EventArgs e)
        {
            if (LED92.Image == bmpGray)
            {
                LED92.Image = bmpRed;
            }
            else if (LED92.Image == bmpRed)
            {
                LED92.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED92);
            serialPort1.Write("k");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("4");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("k");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED93_Click(object sender, EventArgs e)
        {
            if (LED93.Image == bmpGray)
            {
                LED93.Image = bmpRed;
            }
            else if (LED93.Image == bmpRed)
            {
                LED93.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED93);
            serialPort1.Write("k");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("5");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("k");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED94_Click(object sender, EventArgs e)
        {
            if (LED94.Image == bmpGray)
            {
                LED94.Image = bmpRed;
            }
            else if (LED94.Image == bmpRed)
            {
                LED94.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED94);
            serialPort1.Write("k");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("6");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("k");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED95_Click(object sender, EventArgs e)
        {
            if (LED95.Image == bmpGray)
            {
                LED95.Image = bmpRed;
            }
            else if (LED95.Image == bmpRed)
            {
                LED95.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED95);
            serialPort1.Write("k");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("7");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("k");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED96_Click(object sender, EventArgs e)
        {
            if (LED96.Image == bmpGray)
            {
                LED96.Image = bmpRed;
            }
            else if (LED96.Image == bmpRed)
            {
                LED96.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED96);
            serialPort1.Write("k");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("8");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("k");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED97_Click(object sender, EventArgs e)
        {
            if (LED97.Image == bmpGray)
            {
                LED97.Image = bmpRed;
            }
            else if (LED97.Image == bmpRed)
            {
                LED97.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED97);
            serialPort1.Write("l");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("1");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("l");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED98_Click(object sender, EventArgs e)
        {
            if (LED98.Image == bmpGray)
            {
                LED98.Image = bmpRed;
            }
            else if (LED98.Image == bmpRed)
            {
                LED98.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED98);
            serialPort1.Write("l");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("2");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("l");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED99_Click(object sender, EventArgs e)
        {
            if (LED99.Image == bmpGray)
            {
                LED99.Image = bmpRed;
            }
            else if (LED99.Image == bmpRed)
            {
                LED99.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED99);
            serialPort1.Write("l");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("3");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("l");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED100_Click(object sender, EventArgs e)
        {
            if (LED100.Image == bmpGray)
            {
                LED100.Image = bmpRed;
            }
            else if (LED100.Image == bmpRed)
            {
                LED100.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED100);
            serialPort1.Write("l");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("4");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("l");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED101_Click(object sender, EventArgs e)
        {
            if (LED101.Image == bmpGray)
            {
                LED101.Image = bmpRed;
            }
            else if (LED101.Image == bmpRed)
            {
                LED101.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED101);
            serialPort1.Write("l");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("5");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("l");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED102_Click(object sender, EventArgs e)
        {
            if (LED102.Image == bmpGray)
            {
                LED102.Image = bmpRed;
            }
            else if (LED102.Image == bmpRed)
            {
                LED102.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED102);
            serialPort1.Write("l");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("6");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("l");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED103_Click(object sender, EventArgs e)
        {
            if (LED103.Image == bmpGray)
            {
                LED103.Image = bmpRed;
            }
            else if (LED103.Image == bmpRed)
            {
                LED103.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED103);
            serialPort1.Write("l");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("7");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("l");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED104_Click(object sender, EventArgs e)
        {
            if (LED104.Image == bmpGray)
            {
                LED104.Image = bmpRed;
            }
            else if (LED104.Image == bmpRed)
            {
                LED104.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED104);
            serialPort1.Write("l");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("8");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("l");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED105_Click(object sender, EventArgs e)
        {
            if (LED105.Image == bmpGray)
            {
                LED105.Image = bmpRed;
            }
            else if (LED105.Image == bmpRed)
            {
                LED105.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED105);
            serialPort1.Write("m");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("1");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("m");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED106_Click(object sender, EventArgs e)
        {
            if (LED106.Image == bmpGray)
            {
                LED106.Image = bmpRed;
            }
            else if (LED106.Image == bmpRed)
            {
                LED106.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED106);
            serialPort1.Write("m");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("2");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("m");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED107_Click(object sender, EventArgs e)
        {
            if (LED107.Image == bmpGray)
            {
                LED107.Image = bmpRed;
            }
            else if (LED107.Image == bmpRed)
            {
                LED107.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED107);
            serialPort1.Write("m");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("3");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("m");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED108_Click(object sender, EventArgs e)
        {
            if (LED108.Image == bmpGray)
            {
                LED108.Image = bmpRed;
            }
            else if (LED108.Image == bmpRed)
            {
                LED108.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED108);
            serialPort1.Write("m");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("4");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("m");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED109_Click(object sender, EventArgs e)
        {
            if (LED109.Image == bmpGray)
            {
                LED109.Image = bmpRed;
            }
            else if (LED109.Image == bmpRed)
            {
                LED109.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED109);
            serialPort1.Write("m");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("5");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("m");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED110_Click(object sender, EventArgs e)
        {
            if (LED110.Image == bmpGray)
            {
                LED110.Image = bmpRed;
            }
            else if (LED110.Image == bmpRed)
            {
                LED110.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED110);
            serialPort1.Write("m");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("6");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("m");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED111_Click(object sender, EventArgs e)
        {
            if (LED111.Image == bmpGray)
            {
                LED111.Image = bmpRed;
            }
            else if (LED111.Image == bmpRed)
            {
                LED111.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED111);
            serialPort1.Write("m");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("7");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("m");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED112_Click(object sender, EventArgs e)
        {
            if (LED112.Image == bmpGray)
            {
                LED112.Image = bmpRed;
            }
            else if (LED112.Image == bmpRed)
            {
                LED112.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED112);
            serialPort1.Write("m");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("8");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("m");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED113_Click(object sender, EventArgs e)
        {
            if (LED113.Image == bmpGray)
            {
                LED113.Image = bmpRed;
            }
            else if (LED113.Image == bmpRed)
            {
                LED113.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED113);
            serialPort1.Write("n");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("1");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("n");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED114_Click(object sender, EventArgs e)
        {
            if (LED114.Image == bmpGray)
            {
                LED114.Image = bmpRed;
            }
            else if (LED114.Image == bmpRed)
            {
                LED114.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED114);
            serialPort1.Write("n");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("2");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("n");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED115_Click(object sender, EventArgs e)
        {
            if (LED115.Image == bmpGray)
            {
                LED115.Image = bmpRed;
            }
            else if (LED115.Image == bmpRed)
            {
                LED115.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED115);
            serialPort1.Write("n");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("3");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("n");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED116_Click(object sender, EventArgs e)
        {
            if (LED116.Image == bmpGray)
            {
                LED116.Image = bmpRed;
            }
            else if (LED116.Image == bmpRed)
            {
                LED116.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED116);
            serialPort1.Write("n");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("4");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("n");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED117_Click(object sender, EventArgs e)
        {
            if (LED117.Image == bmpGray)
            {
                LED117.Image = bmpRed;
            }
            else if (LED117.Image == bmpRed)
            {
                LED117.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED117);
            serialPort1.Write("n");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("5");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("n");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED118_Click(object sender, EventArgs e)
        {
            if (LED118.Image == bmpGray)
            {
                LED118.Image = bmpRed;
            }
            else if (LED118.Image == bmpRed)
            {
                LED118.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED118);
            serialPort1.Write("n");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("6");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("n");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED119_Click(object sender, EventArgs e)
        {
            if (LED119.Image == bmpGray)
            {
                LED119.Image = bmpRed;
            }
            else if (LED119.Image == bmpRed)
            {
                LED119.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED119);
            serialPort1.Write("n");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("7");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("n");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED120_Click(object sender, EventArgs e)
        {
            if (LED120.Image == bmpGray)
            {
                LED120.Image = bmpRed;
            }
            else if (LED120.Image == bmpRed)
            {
                LED120.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED120);
            serialPort1.Write("n");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("8");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("n");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED121_Click(object sender, EventArgs e)
        {
            if (LED121.Image == bmpGray)
            {
                LED121.Image = bmpRed;
            }
            else if (LED121.Image == bmpRed)
            {
                LED121.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED121);
            serialPort1.Write("o");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("1");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("o");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED122_Click(object sender, EventArgs e)
        {
            if (LED122.Image == bmpGray)
            {
                LED122.Image = bmpRed;
            }
            else if (LED122.Image == bmpRed)
            {
                LED122.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED122);
            serialPort1.Write("o");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("2");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("o");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED123_Click(object sender, EventArgs e)
        {
            if (LED123.Image == bmpGray)
            {
                LED123.Image = bmpRed;
            }
            else if (LED123.Image == bmpRed)
            {
                LED123.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED123);
            serialPort1.Write("o");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("3");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("o");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED124_Click(object sender, EventArgs e)
        {
            if (LED124.Image == bmpGray)
            {
                LED124.Image = bmpRed;
            }
            else if (LED124.Image == bmpRed)
            {
                LED124.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED124);
            serialPort1.Write("o");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("4");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("o");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED125_Click(object sender, EventArgs e)
        {
            if (LED125.Image == bmpGray)
            {
                LED125.Image = bmpRed;
            }
            else if (LED125.Image == bmpRed)
            {
                LED125.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED125);
            serialPort1.Write("o");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("5");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("o");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED126_Click(object sender, EventArgs e)
        {
            if (LED126.Image == bmpGray)
            {
                LED126.Image = bmpRed;
            }
            else if (LED126.Image == bmpRed)
            {
                LED126.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED126);
            serialPort1.Write("o");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("6");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("o");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED127_Click(object sender, EventArgs e)
        {
            if (LED127.Image == bmpGray)
            {
                LED127.Image = bmpRed;
            }
            else if (LED127.Image == bmpRed)
            {
                LED127.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED127);
            serialPort1.Write("o");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("7");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("o");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void LED128_Click(object sender, EventArgs e)
        {
            if (LED128.Image == bmpGray)
            {
                LED128.Image = bmpRed;
            }
            else if (LED128.Image == bmpRed)
            {
                LED128.Image = bmpGray;
            }
            Helper.BlendPictures(this.matrixBackground, this.LED128);
            serialPort1.Write("o");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("8");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("o");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void Parity_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void ComPort_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btn1000ms_Click(object sender, EventArgs e)
        {
            serialPort1.Write("{");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("z");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("{");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void btn500ms_Click(object sender, EventArgs e)
        {
            serialPort1.Write("{");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("u");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("{");
            TxtFeedback.Text = serialPort1.ReadLine();
        }

        private void btn250ms_Click(object sender, EventArgs e)
        {
            serialPort1.Write("{");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("r");
            TxtFeedback.Text = serialPort1.ReadLine();
            serialPort1.Write("{");
            TxtFeedback.Text = serialPort1.ReadLine();
        }
    }
}
